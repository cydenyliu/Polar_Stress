warning off
addpath(genpath('../../supp_script/'))
addpath(genpath('../../supp_matrix/'))

t_mon = numel(2003:2020)*12;
yr = reshape(repmat(2003:2020,12,1),1,t_mon);
mon = reshape(repmat(1:12,numel(2003:2020),1)',1,t_mon);
mday = eomday(yr,mon);
root_dir = '/mnt/data/oaflux/data8';
% root_dir = '/Users/chaoliu/oaflux/data8';
load('../../supp_matrix/ref.mat')
% parameter
De = 20;
ro = 1027.5; ra = 1.25;
Cdi = 0.0055; Cda = 0.00125;
yo = 0;
sgm=3;
Cd=0;
for Cd=[6:10]
    Cdi=Cd*0.001
            if Cd==0
                Cdi=rand(265)*0.01;% random noise pattern
            end

for flt=6%[1 4 6 8 10]
fltm=[num2str(flt) 'x' num2str(flt)];
flt
lat_arc = lat_ao(:,548:end);
lon_arc = lon_ao(:,548:end); lon_arc(lon_arc>180)=lon_arc(lon_arc>180)-360;
lon_df = zeros(size(lon_arc)); lat_df = lon_df;
% for ii = 1:173
%     aa=pathdist([lat_arc(1,ii);lat_arc(1,ii)],[lon_arc(1,ii);lon_arc(3,ii)] );
%     lon_df(:,ii) = aa(2);
%     aa=pathdist([lat_arc(1,ii)-0.25;lat_arc(1,ii)+0.25],[lon_arc(1,ii);lon_arc(1,ii)] );
%     lat_df(:,ii) = aa(2);
% end

for yy = 2012%3:2018
    yy
    yo = yo + 1;
    dofy = 0;

    % loading lon/lat

    % ice extent
    sub_dir_A = [root_dir '/ice_stress/main/input_data/NISE'];
    file_dir_A = [sub_dir_A '/v5/2017/NISE_SSMISF18_20170101.HDFEOS.nc'];
    lat_A = ncread(file_dir_A, 'Latitude');
    lon_A = ncread(file_dir_A, 'Longitude');

    % ice motion
    sub_dir_im = [root_dir '/ice_stress/main/input_data/icemotion_vectors_v4/north/daily'];
    file_dir_im = [sub_dir_im '/icemotion_daily_nh_25km_' num2str(yy) '0101_' num2str(yy) '1231_v4.1.nc'];
    if yo == 1
        lat_i = double(ncread(file_dir_im, 'latitude'));
        lon_i = double(ncread(file_dir_im, 'longitude'));

        % standard
        lon_i = double(lon_i);
        lat_i = double(lat_i);
        lon_standard = lon_i(49:end-48,49:end-48);
        lat_standard = lat_i(49:end-48,49:end-48);
        f = coriolisf(lat_standard);
    end

    angc_g_standard = cosd(lon_standard);
    angs_g_standard = sind(lon_standard);
    % geo vel
    sub_dir_gc_avi = [root_dir '/ice_stress/main/input_data/dt-phy-grids/altimetry_arctic'];
    file_dir_gc = [sub_dir_gc_avi '/version_02_00/multimission/dt_arctic_multimission_sea_level_20110103.nc'];
    if yo == 1
        lat_g = double(ncread(file_dir_gc, 'latitude'));
        lon_g = double(ncread(file_dir_gc, 'longitude'));
        lon_g_db = [lon_g(:,1:174) lon_g(:,176)-360 lon_g(:,174)+360 lon_g(:,176:end)];
        lat_g_db = [lat_g(:,1:174) lat_g(:,176) lat_g(:,174) lat_g(:,176:end)];
    end

    sub_dir_gc = [root_dir '/ice_stress/main/input_data/DOT'];
    file_dir_gc = [sub_dir_gc '/CPOM_DOT.nc'];
    if yo == 1
        lat_g_old = double(ncread(file_dir_gc, 'lat'));
        lon_g_old = double(ncread(file_dir_gc, 'lon'));
        [lat_g_old, lon_g_old] = meshgrid(lat_g_old, lon_g_old);

        % geostrophic to EASE-grid, current & angle

        lon_g_old_p = lon_g_old(1,:);
        lon_g_old_p = lon_g_old_p+360;
        lon_g_old_db = [lon_g_old_p; lon_g_old];
        lat_g_old_db = [lat_g_old(1,:); lat_g_old];
    end

    % wind
    sub_dir_wnd = [root_dir '/OAwnd_Daily'];
    if yo == 1
        lat_ao = -89.875:0.25:89.875;
        lon_ao = .125:0.25:359.875;
        [lat_ao, lon_ao] = meshgrid(lat_ao, lon_ao);
        % save ref lat_ao lon_ao lat_g_old lon_g_old lat_g lon_g lat_A lon_A lat_i lon_i ...
        %     lat_standard lon_standard angc_g angs_g angc_g_standard angs_g_standard cs_square
        % save par f De Cda Cdi ro ra
    end

    % wind
    sub_dir_wnd_nc = [root_dir '/ice_stress/main/input_data/NCEP/wnd10'];
    file_dir_wnd_nc = [sub_dir_wnd_nc '/uwnd/uwnd.10m.gauss.' num2str(yy) '.nc'];
    if yo == 1
        lat_ao_nc = double(ncread(file_dir_wnd_nc, 'lat'));
        lon_ao_nc = double(ncread(file_dir_wnd_nc, 'lon'));
        [lat_ao_nc, lon_ao_nc] = meshgrid(lat_ao_nc, lon_ao_nc);
    end
    for mm = 1:12
        mm
        dinm = eomday(yy,mm);
        % oa Ek
        filename = ([root_dir, '/OAwnd_Daily/', num2str(yy),'/ek.',...
            num2str(yy), num2str(mm, '%02d'), '.mat']);
        load(filename, 'ek')

        % geo vel
        file_dir_gc = [sub_dir_gc '/Daily/Arc/' num2str(yy)];
        if yy < 2011
            xx_g_m = load([file_dir_gc '/uu.' num2str(yy) num2str(mm, '%02d') '.mat']);
            yy_g_m = load([file_dir_gc '/vv.' num2str(yy) num2str(mm, '%02d') '.mat']);
        end

        % wind
        file_dir_wnd = [sub_dir_wnd '/' num2str(yy)];
        uu_ao_m = load([file_dir_wnd '/taux.' num2str(yy) num2str(mm, '%02d') '.mat']);
        vv_ao_m = load([file_dir_wnd '/tauy.' num2str(yy) num2str(mm, '%02d') '.mat']);

        for dd = 1:dinm
            dofy = dofy+1

            % ice extent
            sub_dir_A = [root_dir '/ice_stress/main/input_data/NISE'];
            if yy < 2009
                file_dir_A = [sub_dir_A '/v2/' num2str(yy) '/NISE_SSMIF13_'...
                    num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.nc'];
                if isfile(file_dir_A)
                    Alpha = ncread(file_dir_A, 'Extent', [1 1], [inf inf]);
                else
                    file_dir_A = [sub_dir_A '/v2/' num2str(yy) '/NISE_SSMIF13_'...
                        num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.mat'];
                    Alpha = load(file_dir_A);
                    Alpha = Alpha.Extent;
                end
            elseif yy == 2009
                if mm < 10
                    file_dir_A = [sub_dir_A '/v2/' num2str(yy) '/NISE_SSMIF13_'...
                        num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.nc'];
                    if isfile(file_dir_A)
                        Alpha = ncread(file_dir_A, 'Extent', [1 1], [inf inf]);
                    else
                        file_dir_A = [sub_dir_A '/v2/' num2str(yy) '/NISE_SSMIF13_'...
                            num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.mat'];
                        Alpha = load(file_dir_A);
                        Alpha = Alpha.Extent;
                    end
                else
                    file_dir_A = [sub_dir_A '/v4/' num2str(yy) '/NISE_SSMISF17_'...
                        num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.nc'];
                    if isfile(file_dir_A)
                        Alpha = ncread(file_dir_A, 'Extent', [1 1], [inf inf]);
                    else
                        file_dir_A = [sub_dir_A '/v4/' num2str(yy) '/NISE_SSMISF17_'...
                            num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.mat'];
                        Alpha = load(file_dir_A);
                        Alpha = Alpha.Extent;
                    end
                end
            elseif yy < 2016
                file_dir_A = [sub_dir_A '/v4/' num2str(yy) '/NISE_SSMISF17_'...
                    num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.nc'];
                if isfile(file_dir_A)
                    Alpha = ncread(file_dir_A, 'Extent', [1 1], [inf inf]);
                else
                    file_dir_A = [sub_dir_A '/v4/' num2str(yy) '/NISE_SSMISF17_'...
                        num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.mat'];
                    Alpha = load(file_dir_A);
                    Alpha = Alpha.Extent;
                end
            elseif yy==2016
                if mm < 12
                    file_dir_A = [sub_dir_A '/v4/' num2str(yy) '/NISE_SSMISF17_'...
                        num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.nc'];
                    if isfile(file_dir_A)
                        Alpha = ncread(file_dir_A, 'Extent', [1 1], [inf inf]);
                    else
                        file_dir_A = [sub_dir_A '/v4/' num2str(yy) '/NISE_SSMISF17_'...
                            num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.mat'];
                        Alpha = load(file_dir_A);
                        Alpha = Alpha.Extent;
                    end
                else
                    file_dir_A = [sub_dir_A '/v5/' num2str(yy) '/NISE_SSMISF18_'...
                        num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.nc'];
                    if isfile(file_dir_A)
                        Alpha = ncread(file_dir_A, 'Extent', [1 1], [inf inf]);
                    else
                        file_dir_A = [sub_dir_A '/v5/' num2str(yy) '/NISE_SSMISF18_'...
                            num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.mat'];
                        Alpha = load(file_dir_A);
                        Alpha = Alpha.Extent;
                    end
                end
            else
                file_dir_A = [sub_dir_A '/v5/' num2str(yy) '/NISE_SSMISF18_'...
                    num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.nc'];
                if isfile(file_dir_A)
                    Alpha = ncread(file_dir_A, 'Extent', [1 1], [inf inf]);
                else
                    file_dir_A = [sub_dir_A '/v5/' num2str(yy) '/NISE_SSMISF18_'...
                        num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.mat'];
                    Alpha = load(file_dir_A);
                    Alpha = Alpha.Extent;
                end
            end

            Alpha = double(Alpha);

            % ice motion
            xx_i = double(ncread(file_dir_im, 'u', [1 1 dofy], [inf inf 1]));
            yy_i = double(ncread(file_dir_im, 'v', [1 1 dofy], [inf inf 1]));

            % geo vel
            if yy < 2011
                xx_g = xx_g_m.uu(:,:,dd);
                yy_g = yy_g_m.vv(:,:,dd);
            else
                file_dir_gc = [sub_dir_gc_avi '/daily_interp/' num2str(yy)];
                xy_g_m = load([file_dir_gc '/uv.' num2str(yy)  num2str(mm, '%02d')  num2str(dd, '%02d') '.mat']);
                xx_g = xy_g_m.uu;
                yy_g = xy_g_m.vv;
            end

            % wind
            uu_ao = uu_ao_m.taux(:,:,dd);
            vv_ao = vv_ao_m.tauy(:,:,dd);

            % wind
            file_dir_wnd_nc = [sub_dir_wnd_nc '/uwnd/uwnd.10m.gauss.' num2str(yy) '.nc'];
            uu_ao_m_nc = double(ncread(file_dir_wnd_nc, 'uwnd', [1 1 dofy*4-3], [inf inf 4]));
            uu_ao_nc = squeeze(mean(uu_ao_m_nc,3,'omitnan'));
            file_dir_wnd_nc = [sub_dir_wnd_nc '/vwnd/vwnd.10m.gauss.' num2str(yy) '.nc'];
            vv_ao_m_nc = double(ncread(file_dir_wnd_nc, 'vwnd', [1 1 dofy*4-3], [inf inf 4]));
            vv_ao_nc = squeeze(mean(vv_ao_m_nc,3,'omitnan'));

            % interpolation

            % refit EASE-grid
            % ice motion
            xx_i_standard = xx_i(49:end-48,49:end-48);
            yy_i_standard = yy_i(49:end-48,49:end-48);
            xx_i_standard(isnan(xx_i_standard)) = 0;
            yy_i_standard(isnan(yy_i_standard)) = 0;

            % ice extent
            Alpha_standard = double(fliplr(Alpha(229:end-228, 229:end-228)));
            Alpha_standard(Alpha_standard==0) = nan;
            Alpha_standard(Alpha_standard==255) = 0;
            Alpha_standard(Alpha_standard>100) = nan;

            % geostrophic to EASE-grid
            xx_g = double(xx_g);
            yy_g = double(yy_g);

            if yy > 2010
                xx_g_db = [xx_g(:,1:174) xx_g(:,176) xx_g(:,174) xx_g(:,176:end)];
                yy_g_db = [yy_g(:,1:174) yy_g(:,176) xx_g(:,174) yy_g(:,176:end)];
                xx_g_db(isnan(xx_g_db)) = 0; yy_g_db(isnan(yy_g_db)) = 0;
                xx_g_standard = griddata(lon_g_db, lat_g_db, xx_g_db, lon_standard, lat_standard);
                yy_g_standard = griddata(lon_g_db, lat_g_db, yy_g_db, lon_standard, lat_standard);
                clear xx_g_db yy_g_db
            else
                xx_g_db = [xx_g(1,:); xx_g];
                yy_g_db = [yy_g(1,:); yy_g];
                xx_g_db(isnan(xx_g_db)) = 0; yy_g_db(isnan(yy_g_db)) = 0;
                xx_g_standard = griddata(lon_g_old_db, lat_g_old_db, xx_g_db, lon_standard, lat_standard);
                yy_g_standard = griddata(lon_g_old_db, lat_g_old_db, yy_g_db, lon_standard, lat_standard);
                clear xx_g_db yy_g_db
            end

            % wind stress to EASE-grid
            lon_ao(lon_ao>180) = lon_ao(lon_ao>180)-360;
            lon_ao_p = lon_ao(721,:)+360;
            lon_ao_db = [lon_ao_p; lon_ao]; lat_ao_db = [lat_ao(721,:); lat_ao];
            uu_ao_db = [uu_ao(721,:); uu_ao]; vv_ao_db = [vv_ao(721,:); vv_ao];
            uu_ao_db(isnan(uu_ao_db)) = 0; vv_ao_db(isnan(vv_ao_db)) = 0;
            uu_ao_standard = griddata(lon_ao_db, lat_ao_db, uu_ao_db, lon_standard, lat_standard);
            vv_ao_standard = griddata(lon_ao_db, lat_ao_db, vv_ao_db, lon_standard, lat_standard);
            clear lon_ao_db lat_ao_db uu_ao_db vv_ao_db

            lon_ao_nc(lon_ao_nc>180) = lon_ao_nc(lon_ao_nc>180)-360;
            lon_ao_nc_p = lon_ao_nc(97,:)-360;
            lon_ao_nc_db = [lon_ao_nc_p; lon_ao_nc]; lat_ao_nc_db = [lat_ao_nc(97,:); lat_ao_nc];
            uu_ao_nc_db = [uu_ao_nc(97,:); uu_ao_nc]; vv_ao_nc_db = [vv_ao_nc(97,:); vv_ao_nc];
            uu_ao_nc_db(isnan(uu_ao_nc_db)) = 0; vv_ao_nc_db(isnan(vv_ao_nc_db)) = 0;
            uu_ao_nc_standard = griddata(lon_ao_nc_db, lat_ao_nc_db, uu_ao_nc_db, lon_standard, lat_standard);
            vv_ao_nc_standard = griddata(lon_ao_nc_db, lat_ao_nc_db, vv_ao_nc_db, lon_standard, lat_standard);
            clear lon_ao_nc_db lat_ao_nc_db uu_ao_nc_db vv_ao_nc_db

            % masks
            mask_A = ~isnan(Alpha_standard);
            % mask_i = ~isnan(xx_i_standard) .* ~isnan(xx_i_standard);
            % mask_e = ~isnan(tauu_ao_standard) .* ~isnan(tauv_ao_standard);
            % mask_g = ~isnan(xx_g_standard) .* ~isnan(yy_g_standard);
            mask_standard = double(mask_A);
            mask_standard(mask_standard<1) = nan;
            mask_standard(lat_standard>87.34) = nan;

            % xy to uv
            uu_g_standard = xx_g_standard;
            vv_g_standard = yy_g_standard;
            % ice motion
            uu_i_standard = xx_i_standard.*angc_g_standard + yy_i_standard.*angs_g_standard;
            vv_i_standard =-xx_i_standard.*angs_g_standard + yy_i_standard.*angc_g_standard;

            % Complex
            % U_g = uu_g_standard+vv_g_standard*1i;
            if flt~=1
                uu_g_standard=Gau_conv_cl(uu_g_standard,flt,flt,sgm);
                vv_g_standard=Gau_conv_cl(vv_g_standard,flt,flt,sgm);
            end
                U_g = uu_g_standard+vv_g_standard*1i;

            U_i = uu_i_standard+vv_i_standard*1i; U_i = U_i/100; % cm/s to m/s

            % TAU_e
            wnd_e = uu_ao_standard+vv_ao_standard*1i;
            TAU_e = wnd_e;

            wnd_e_nc = uu_ao_nc_standard+vv_ao_nc_standard*1i;
            TAU_e_nc = ra*Cda*abs(wnd_e_nc).*wnd_e_nc;

            % TAU_e(abs(TAU_e)==0) = TAU_e_nc(abs(TAU_e)==0);

            Alpha_standard_o = Alpha_standard;
            Alpha_standard_o(isnan(Alpha_standard_o)) = 0;
            U_i(isnan(U_i)) = 0+0*1i;
            U_g(isnan(U_g)) = 0+0*1i;

            % MRIteration

            [TAU, k] = modified_richardson_iteration(0.1, 10^-5, 5000, Alpha_standard_o, TAU_e, U_i, U_g, f, ro, De, Cdi);

            % TAU_i = (TAU - (1-Alpha_standard/100).*TAU_e) ./ (Alpha_standard/100);
            % TAU = TAU .* mask_standard;
            % TAU_i = TAU_i .* mask_standard;
            % TAU_e = TAU_e .* mask_standard;
            
            TAU_output(:,:,dofy) = TAU;
            iteration_k(1,dofy) = k;
            U_i_input(:,:,dofy) = U_i;
            U_g_input(:,:,dofy) = U_g;
            Alpha_input(:,:,dofy) = Alpha_standard;

            % femp;
            if mm == 1
                mkdir([root_dir, '/ice_stress/main/ice_drag/Arctic/', num2str(Cd, '%02d'), '/']);
                % mkdir([root_dir, '/ice_stress/step_fig/ovi/', fltm, '/', num2str(Cd, '%02d'), '/']);
                % mkdir([root_dir, '/ice_stress/step_fig/ovi/', fltm, '/', num2str(Cd, '%02d'), '/', num2str(yy)]);
                % mkdir([root_dir, '/ice_stress/step_fig/ovi/', fltm, '/', num2str(Cd, '%02d'), '/', num2str(yy), '/day']);
                % mkdir([root_dir, '/ice_stress/step_fig/ovi/', fltm, '/', num2str(Cd, '%02d'), '/', num2str(yy), '/ek']);
            end
            % figname=strcat(root_dir, '/ice_stress/step_fig/ovi/', fltm, '/', num2str(Cd, '%02d'), '/', num2str(yy),'/day/chk.',num2str(yy), num2str(mm, '%02d'), num2str(dd, '%02d'), '.png');
            % print(figname,'-dpng')


            % Ekman
            ek_o = squeeze(ek(:,548:end,dd));

            xxx = real(TAU)./f/ro; yyy = imag(TAU)./f/ro;
            m_tau = yyy - xxx*1i;

            lon_xxs = [-lon_standard(133,:); lon_standard];
            lat_xxs = [lat_standard(133,:); lat_standard];
            xxx_db = [xxx(133,:); xxx]; yyy_db = [yyy(133,:); yyy];
            xxx_db(isnan(xxx_db)) = 0; yyy_db(isnan(yyy_db)) = 0;
            xxx_arc = griddata(lon_xxs, lat_xxs, xxx_db, lon_arc, lat_arc);
            yyy_arc = griddata(lon_xxs, lat_xxs, yyy_db, lon_arc, lat_arc);

            yyy_arc = [yyy_arc(end,:); yyy_arc; yyy_arc(1,:)];

            xxx_arc = [2*xxx_arc(:,1)-xxx_arc(:,2) xxx_arc 2*xxx_arc(:,end)-xxx_arc(:,end-1)];

            xxx_dy = (xxx_arc(:,3:end)-xxx_arc(:,1:end-2))./lat_df;
            yyy_dx = (yyy_arc(3:end,:)-yyy_arc(1:end-2,:))./lon_df;

            ep_tau = yyy_dx - xxx_dy;

            lon_arc_db = [lon_arc(720,:)-360;lon_arc(721,:)+360;lon_arc];
            lat_arc_db = [lat_arc(720,:);lat_arc(721,:);lat_arc];
            ep_tau_db = [ep_tau(720,:);ep_tau(721,:);ep_tau];
            ep_tau = griddata(lon_arc_db, lat_arc_db, ep_tau_db, lon_standard, lat_standard);

            ep_tau_db = [ek_o(720,:);ek_o(721,:);ek_o];
            ep_tau_o = griddata(lon_arc_db, lat_arc_db, ep_tau_db, lon_standard, lat_standard);
            % ep_femp;

            m_TAU_output(:,:,dofy) = m_tau;
            ep_TAU_output(:,:,dofy) = ep_tau;
            % figname=strcat(root_dir, '/ice_stress/step_fig/ovi/', fltm, '/', num2str(Cd, '%02d'), '/', num2str(yy),'/ek/chk.', num2str(yy), num2str(mm, '%02d'), num2str(dd, '%02d'), '.png');
            % print(figname,'-dpng')
            clc
        end
    end

    file=strcat(root_dir, '/ice_stress/main/ice_drag/Arctic/', num2str(Cd, '%02d'), '/tau.',num2str(yy), '.nc');
    if exist(file, 'file')==2
        delete(file);
    end

    tmp_att.long_name='longitude';
    tmp_att.units='degree_east';
    nccreatewrite(file,'lon',{'x','y'},lon_standard,tmp_att)
    tmp_att.long_name='latitude';
    tmp_att.units='degree_north';
    nccreatewrite(file,'lat',{'x','y'},lat_standard,tmp_att)

    tmp_att.long_name='Total Stress U, output';
    tmp_att.units='N·m-2';
    nccreatewrite(file,'TAUU',{'x','y','t'},real(TAU_output),tmp_att)
    tmp_att.long_name='Total Stress V, output';
    tmp_att.units='N·m-2';
    nccreatewrite(file,'TAUV',{'x','y','t'},imag(TAU_output),tmp_att)
    tmp_att.long_name='Ekman Transport, output';
    tmp_att.units='m·s−1';
    nccreatewrite(file,'e_TAU',{'x','y','t'},ep_TAU_output,tmp_att)

    % tmp_att.long_name='Ice Extent, input';
    % tmp_att.units='percentage';
    % nccreatewrite(file,'Alpha',{'x','y','t'},Alpha_input,tmp_att)
    % tmp_att.long_name='Ice Motion U, input';
    % tmp_att.units='m/s';
    % nccreatewrite(file,'U_i',{'x','y','t'},real(U_i_input),tmp_att)
    % tmp_att.long_name='Geostrophic Velocity U, input';
    % tmp_att.units='m/s';
    % nccreatewrite(file,'U_g',{'x','y','t'},real(U_g_input),tmp_att)
    % tmp_att.long_name='Ice Motion V, input';
    % tmp_att.units='m/s';
    % nccreatewrite(file,'V_i',{'x','y','t'},imag(U_i_input),tmp_att)
    % tmp_att.long_name='Geostrophic Velocity V, input';
    % tmp_att.units='m/s';
    % nccreatewrite(file,'V_g',{'x','y','t'},imag(U_g_input),tmp_att)
    tmp_att.long_name='Iteration Number';
    tmp_att.units='generic';
    nccreatewrite(file,'iteration',{'t'},iteration_k,tmp_att)

    clear TAU_output m_TAU_output ep_TAU_output Alpha_input U_i_input U_g_input iteration_k
end
end
end

%% %% %%
% getting iteration
function [x, k] = modified_richardson_iteration(omega, tol, max_iter, Alpha_standard, TAU_e, U_i, U_g, f, ro, De, Cd)
% A_fun: function handle that returns A based on x
% b: right-hand side vector
% omega: relaxation parameter (0 < omega < 2)
% tol: tolerance for convergence
% max_iter: maximum number of iterations

% Initialize solution vector
x = zeros(size(Alpha_standard));

% Perform modified Richardson iteration
for k = 1:max_iter
    [A, b] = Ab_fun(x, Alpha_standard, TAU_e, U_i, U_g, f, ro, De, Cd); % Compute A & b based on current x
    x_new = x + omega * (b - A .* x);
    % x_new(x_new>10) = nan;
    % Check convergence
    jj = abs(x_new - x);
    if max(jj(:)) < tol
        break;
    end

    % Update solution vector
    x = x_new;
end
% fprintf(['Converged in ', num2str(k), ' iterations.'])
end

% getting A & b
function [A, b] = Ab_fun(x, Alpha_standard, TAU_e, U_i, U_g, f, ro, De, Cd)
% Ab_fun: function handle that returns A based on x
% Full function
lhs = 1;
rhs2 = (1-Alpha_standard/100).*TAU_e;
U_e = (sqrt(2)*exp(-1i*pi/4)./(f*ro*De)).*x;
U_r = U_i - (U_e + U_g); a_U_r = abs(U_r);
% rhs1_0 = -ro*Cd*a_U_r.*U_e;
rhs1_1 = ro.*Cd.*a_U_r.*(U_i - U_g).*Alpha_standard/100;
% Reassemble
A = lhs+ro.*Cd.*a_U_r.*(sqrt(2)*exp(-1i*pi/4)./(f*ro*De)).*Alpha_standard/100;
b = rhs1_1+rhs2;
end
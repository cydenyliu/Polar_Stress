
-------------------------------------------------------------------------------------------------------------------
Arctic/Antarctic Ocean-Surface Stress Analysis, 2013-2018
-------------------------------------------------i-----------------------------------------------------------------

- This directory contains the codes for ice-water drag coefficient sensitivity tests:
  README                              This file
  tau_oa_ovi_drag_arc.m                   script modified from core script codes/tau_Ekman_cal.m for generating the daily fields in Arctic
  tau_oa_ovi_drag_ant.m                   script modified from core script codes/tau_Ekman_cal.m for generating the daily fields in Antarctic

All data are calculated with the tau_oa_ovi_drag.m with different filter setting (line 17)
warning off
load('clm.mat')
load('../../../ref.mat')
load('../../../topo_arc.mat','bgr_msk');
addpath(genpath('../../../../m_map'))
cc=1;
for jj=[1:10 0]
    ap=ncread([num2str(jj, '%02d') '/tau.2011.nc'],'Alpha');
    tx=ncread([num2str(jj, '%02d') '/tau.2011.nc'],'TAUU');
    ty=ncread([num2str(jj, '%02d') '/tau.2011.nc'],'TAUV');
    ep=ncread([num2str(jj, '%02d') '/tau.2011.nc'],'e_TAU');

    tu=abs(tx+ty*1i);amp=ap;amp(amp<15)=nan;amp(amp>=15)=1;

    dragts.ice.amp(cc,:,:)=squeeze(sum(amp,[1 2],'omitnan'));
    dragts.ice.tau(cc,:,:)=squeeze(mean(tu.*amp,[1 2],'omitnan'));
    dragts.ice.ekm(cc,:,:)=squeeze(mean(ep.*amp,[1 2],'omitnan'));
    dragts.bgr.amp(cc,:,:)=squeeze(sum(amp.*repmat(bgr_msk,1,1,size(amp,3)),[1 2],'omitnan'));
    dragts.bgr.tau(cc,:,:)=squeeze(mean(tu.*amp.*repmat(bgr_msk,1,1,size(amp,3)),[1 2],'omitnan'));
    dragts.bgr.ekm(cc,:,:)=squeeze(mean(ep.*amp.*repmat(bgr_msk,1,1,size(amp,3)),[1 2],'omitnan'));
    dragts.bgf.tau(cc,:,:)=squeeze(mean(tu.*repmat(bgr_msk,1,1,size(amp,3)),[1 2],'omitnan'));
    dragts.bgf.ekm(cc,:,:)=squeeze(mean(ep.*repmat(bgr_msk,1,1,size(amp,3)),[1 2],'omitnan'));

    % ap=ap(:,:,[74 166 258 349]);ep=ep(:,:,[74 166 258 349]);
    % tx=tx(:,:,[74 166 258 349]);ty=ty(:,:,[74 166 258 349]);
    % tu=abs(tx+ty*1i);
    % 
    % for ll=1:4
    %     figure(ll);%
    %     set(gcf,'unit','pixel',"Position",[1,80,1350,900])
    %     subplot(2,2,cc)
    %     m_proj('azimuthal equal-area','latitude',90,'radius',43,'rectbox','on');
    %     hold on
    %     clim=tu(:,:,ll);
    %     clim(lat_standard>89.5)=nan;
    %     m_pcolor(lon_standard,lat_standard,clim,'facealpha',0.6);shading interp
    %     ch=colorbar;
    %     set(ch,'location','southoutside','unit','normalized');
    % 
    %     colormap(gca,tau_map);
    %     ylabel(ch,'N/m^2','FontSize',15)
    %     caxis([0 1]*0.3)
    % 
    %     % h=m_streamline(lon_standard(1:5:end,1:5:end),lat_standard(1:5:end,1:5:end),...
    %     %     tx(1:5:end,1:5:end,ll),ty(1:5:end,1:5:end,ll),8);
    %     % set(h,'color',[1 1 1]*0.3,'linew',1.2);
    % 
    %     m_coast('patch',[.7 .7 .7],'edgecolor','k');
    %     m_grid('xtick',12,'tickdir','out','ytick',[70 80 90],'yticklabel',['',''],'labelcolor','w','linest','-');
    %     title({['Drag Coef=' num2str(jj) 'x10^{-3}'];'';''})
    %     ylabel([num2str(3*ll,'%02d'),'/15/2011'])
    % 
    %     m_contour(lon_standard,lat_standard,ap(:,:,ll),[15 15],'m','linewidth',2);
    %     hold off
    % 
    %     figure(ll+4);%
    %     set(gcf,'unit','pixel',"Position",[1,80,1350,900])
    %     subplot(2,2,cc)
    %     m_proj('azimuthal equal-area','latitude',90,'radius',43,'rectbox','on');
    %     hold on
    %     clim=ep(:,:,ll)*2400*3600;
    %     clim(lat_standard>89.5)=nan;
    %     m_pcolor(lon_standard,lat_standard,clim,'facealpha',0.7);shading interp
    % 
    %     ch=colorbar;
    %     set(ch,'location','southoutside','unit','normalized');
    %     ylabel(ch,'cm/day','FontSize',15)
    %     caxis([-1 1]*100)
    %     colormap(gca,tnd_map);
    % 
    %     m_coast('patch',[.7 .7 .7],'edgecolor','k');
    %     m_grid('xtick',12,'tickdir','out','ytick',[70 80 90],'yticklabel',['',''],'labelcolor','w','linest','-');
    %     title({['Drag Coef=' num2str(jj) 'x10^{-3}'];'';''})
    %     ylabel([num2str(3*ll,'%02d'),'/15/2011'])
    % 
    %     m_contour(lon_standard,lat_standard,ap(:,:,ll),[15 15],'m','linewidth',2);
    % 
    % end

    cc=cc+1;
end
% for jj=1:8
%     figure(jj)
%         exportgraphics(gcf,['01/', num2str(jj, '%02d'),'.png']);
% end

save('../../../ice_arc_ts.mat','dragts','-append');
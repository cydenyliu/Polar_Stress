clear;
addlst={'../ice_stress/exp/ovi/1x1/';...
    '../ice_stress/exp/ovi/4x4/';...
    '../ice_stress/exp/ovi/6x6/';...
    '../ice_stress/exp/ovi/8x8/';...
    '../ice_stress/exp/ovi/10x10/';...
    '../ice_stress/exp/saga/';...
    '../ice_stress/exp/oa/'};
explst={'CLS1';'CLS4';'CLS6';'CLS8';'CLS10';'SAGA';'CPOM'};

tt.CLS1=zeros(265,265,365);tt.CLS4=tt.CLS1;tt.CLS6=tt.CLS1;tt.CLS8=tt.CLS1;
tt.CLS10=tt.CLS1;tt.CPOM=tt.CLS1;tt.SAGA=tt.CLS1;
et=tt;kt=tt;
tt_lite.CLS1=zeros(265,265,4);tt_lite.CLS4=tt_lite.CLS1;tt_lite.CLS6=tt_lite.CLS1;
tt_lite.CLS8=tt_lite.CLS1;tt_lite.CLS10=tt_lite.CLS1;tt_lite.CPOM=tt_lite.CLS1;
tt_lite.SAGA=tt_lite.CLS1;
et_lite=tt;kt_lite=tt;

ii=7;addlst{ii}
ap=zeros(265,265,365);
for jj=1:8
    ap=ap+ncread([addlst{ii} 'tau.20' num2str(jj+10, '%02d') '.nc'],'Alpha',[1 1 1],[inf inf 365]);
end
ap=ap/jj;    a_lite=ap(:,:,[74 166 258 349]);

aa_msk=double(ap>=15);aa_msk(aa_msk==0)=nan;
lat=ncread([addlst{ii} 'tau.20' num2str(jj+10, '%02d') '.nc'],'lat');
l_msk=double(lat>66);l_msk(l_msk==0)=nan;
load('ref.mat', 'bgr_msk');

for ii=1:7;addlst{ii}
    tx=zeros(265,265,365);ty=tx;tp=tx;ep=tx;kx=tx;ky=tx;
    for jj=1:3
        tx=tx+ncread([addlst{ii} 'tau.20' num2str(jj+10, '%02d') '.nc'],'TAUU',[1 1 1],[inf inf 365]);
        ty=ty+ncread([addlst{ii} 'tau.20' num2str(jj+10, '%02d') '.nc'],'TAUV',[1 1 1],[inf inf 365]);
        kx=kx+ncread([addlst{ii} 'tau.20' num2str(jj+10, '%02d') '.nc'],'U_g',[1 1 1],[inf inf 365]);
        ky=ky+ncread([addlst{ii} 'tau.20' num2str(jj+10, '%02d') '.nc'],'V_g',[1 1 1],[inf inf 365]);
        ep=ep+ncread([addlst{ii} 'tau.20' num2str(jj+10, '%02d') '.nc'],'e_TAU',[1 1 1],[inf inf 365]);
    end
    tx=tx/jj;ty=ty/jj;ep=ep/jj;
    tt.(explst{ii})=abs(tx+ty*1i);et.(explst{ii})=ep;
    kt.(explst{ii})=0.5*(kx.^2+ky.^2);
    tt_lite.(explst{ii})=tt.(explst{ii})(:,:,[74 166 258 349]);
    et_lite.(explst{ii})=et.(explst{ii})(:,:,[74 166 258 349]);
    kt_lite.(explst{ii})=kt.(explst{ii})(:,:,[74 166 258 349]);

end
% save ice_arc_stat_tri tt_lite kt_lite et_lite a_lite 
statn={'tau';'ekm';'mke'};
for jj=1:365
    a_msk=aa_msk(:,:,jj);
    jj
    for vv=1:3

        for ii=1:6
            if vv==1
                tt_tgt=tt.(explst{ii})(:,:,jj);
                tt_ref6=tt.(explst{6})(:,:,jj);
                tt_ref7=tt.(explst{7})(:,:,jj);
            elseif vv==2
                tt_tgt=et.(explst{ii})(:,:,jj);
                tt_ref6=et.(explst{6})(:,:,jj);
                tt_ref7=et.(explst{7})(:,:,jj);
            elseif vv==3
                tt_tgt=kt.(explst{ii})(:,:,jj);
                tt_ref6=kt.(explst{6})(:,:,jj);
                tt_ref7=kt.(explst{7})(:,:,jj);
            end

            stat.(statn{vv}).ice.std(ii,jj)=nanstd2(tt_tgt.*a_msk);
            stat.(statn{vv}).arc.std(ii,jj)=nanstd2(tt_tgt.*l_msk);
            stat.(statn{vv}).ice.ave(ii,jj)=mean(tt_tgt.*a_msk,"all",'omitnan');
            stat.(statn{vv}).arc.ave(ii,jj)=mean(tt_tgt.*l_msk,"all",'omitnan');
            stat.(statn{vv}).beau.std(ii,jj)=nanstd2(tt_tgt.*bgr_msk);
            stat.(statn{vv}).beau.ave(ii,jj)=mean(tt_tgt.*bgr_msk,"all",'omitnan');
            if ii<6
                tt_ref=tt_ref6;
                stat.(statn{vv}).ice.cor.saga(ii,jj)=nancorr2(tt_tgt.*a_msk,tt_ref.*a_msk);
                stat.(statn{vv}).arc.cor.saga(ii,jj)=nancorr2(tt_tgt.*l_msk,tt_ref.*l_msk);
                stat.(statn{vv}).beau.cor.saga(ii,jj)=nancorr2(tt_tgt.*bgr_msk,tt_ref.*bgr_msk);
                [stat.(statn{vv}).ice.mad.saga(ii,jj), stat.(statn{vv}).ice.rmsd.saga(ii,jj),...
                    stat.(statn{vv}).ice.mse.saga(ii,jj), stat.(statn{vv}).ice.snr.saga(ii,jj),...
                    stat.(statn{vv}).ice.psnr.saga(ii,jj), stat.(statn{vv}).ice.ssim.saga(ii,jj)]=mps(tt_tgt.*a_msk,tt_ref.*a_msk);
                [stat.(statn{vv}).arc.mad.saga(ii,jj), stat.(statn{vv}).arc.rmsd.saga(ii,jj),...
                    stat.(statn{vv}).arc.mse.saga(ii,jj), stat.(statn{vv}).arc.snr.saga(ii,jj),...
                    stat.(statn{vv}).arc.psnr.saga(ii,jj), stat.(statn{vv}).arc.ssim.saga(ii,jj)]=mps(tt_tgt.*l_msk,tt_ref.*l_msk);
                [stat.(statn{vv}).beau.mad.saga(ii,jj), stat.(statn{vv}).beau.rmsd.saga(ii,jj),...
                    stat.(statn{vv}).beau.mse.saga(ii,jj), stat.(statn{vv}).beau.snr.saga(ii,jj),...
                    stat.(statn{vv}).beau.psnr.saga(ii,jj), stat.(statn{vv}).beau.ssim.saga(ii,jj)]=mps(tt_tgt.*bgr_msk,tt_ref.*bgr_msk);

                % FFT of original and filtered data
                stat.(statn{vv}).ice.anpr.saga(ii,jj)=fft_anpr(tt_tgt.*a_msk,tt_ref.*a_msk);
                stat.(statn{vv}).arc.anpr.saga(ii,jj)=fft_anpr(tt_tgt.*l_msk,tt_ref.*l_msk);
                stat.(statn{vv}).beau.anpr.saga(ii,jj)=fft_anpr(tt_tgt.*bgr_msk,tt_ref.*bgr_msk);
            
            end
            tt_ref=tt_ref7;
            stat.(statn{vv}).ice.cor.cpom(ii,jj)=nancorr2(tt_tgt.*a_msk,tt_ref.*a_msk);
            stat.(statn{vv}).arc.cor.cpom(ii,jj)=nancorr2(tt_tgt.*l_msk,tt_ref.*l_msk);
            stat.(statn{vv}).beau.cor.cpom(ii,jj)=nancorr2(tt_tgt.*bgr_msk,tt_ref.*bgr_msk);
            [stat.(statn{vv}).ice.mad.cpom(ii,jj), stat.(statn{vv}).ice.rmsd.cpom(ii,jj),...
                stat.(statn{vv}).ice.mse.cpom(ii,jj), stat.(statn{vv}).ice.snr.cpom(ii,jj),...
                stat.(statn{vv}).ice.psnr.cpom(ii,jj), stat.(statn{vv}).ice.ssim.cpom(ii,jj)]=mps(tt_tgt.*a_msk,tt_ref.*a_msk);
            [stat.(statn{vv}).arc.mad.cpom(ii,jj), stat.(statn{vv}).arc.rmsd.cpom(ii,jj),...
                stat.(statn{vv}).arc.mse.cpom(ii,jj), stat.(statn{vv}).arc.snr.cpom(ii,jj),...
                stat.(statn{vv}).arc.psnr.cpom(ii,jj), stat.(statn{vv}).arc.ssim.cpom(ii,jj)]=mps(tt_tgt.*l_msk,tt_ref.*l_msk);
            [stat.(statn{vv}).beau.mad.cpom(ii,jj), stat.(statn{vv}).beau.rmsd.cpom(ii,jj),...
                stat.(statn{vv}).beau.mse.cpom(ii,jj), stat.(statn{vv}).beau.snr.cpom(ii,jj),...
                stat.(statn{vv}).beau.psnr.cpom(ii,jj), stat.(statn{vv}).beau.ssim.cpom(ii,jj)]=mps(tt_tgt.*bgr_msk,tt_ref.*bgr_msk);

            % FFT of original and filtered data
            stat.(statn{vv}).ice.anpr.cpom(ii,jj)=fft_anpr(tt_tgt.*a_msk,tt_ref.*a_msk);
            stat.(statn{vv}).arc.anpr.cpom(ii,jj)=fft_anpr(tt_tgt.*l_msk,tt_ref.*l_msk);
            stat.(statn{vv}).beau.anpr.cpom(ii,jj)=fft_anpr(tt_tgt.*bgr_msk,tt_ref.*bgr_msk);
        end
        ii=7;
        stat.(statn{vv}).ice.std(ii,jj)=nanstd2(tt_ref7.*a_msk);
        stat.(statn{vv}).arc.std(ii,jj)=nanstd2(tt_ref7.*l_msk);
        stat.(statn{vv}).ice.ave(ii,jj)=mean(tt_ref7.*a_msk,"all",'omitnan');
        stat.(statn{vv}).arc.ave(ii,jj)=mean(tt_ref7.*l_msk,"all",'omitnan');
        stat.(statn{vv}).beau.std(ii,jj)=nanstd2(tt_ref7.*bgr_msk);
        stat.(statn{vv}).beau.ave(ii,jj)=mean(tt_ref7.*bgr_msk,"all",'omitnan');
        
    end
end

save ice_arc_stat stat  aa_msk %l_msk tt et ke
%%
function A=nanstd2(U)
U(isnan(U))=[];
A=std2(U);
end
function A=nancorr2(U,V)
id1=find(isnan(U));
id2=find(isnan(V));
id=union(id1,id2);
U(id)=[];
V(id)=[];
A=corr2(U,V);
end
function [mad, rmsd, mse, snr, psnr, ssim_value]=mps(B, A)
% Assuming A and B are 2D matrices representing images
mad = mean(abs(A - B),'all','omitnan');

% Calculate the maximum intensity value (assuming A and B are uint8 images)
max_intensity = max(A,[],'all','omitnan');

% Mean squared error (MSE)
mse = mean((A - B).^2,'all','omitnan');

rmsd = sqrt(mse);

% PSNR
psnr = 10 * log10(max_intensity^2 / mse);

% Assuming A is the original (noise-free) image
noise_free_power = mean(A.^2,'all','omitnan');  % Mean squared intensity of original image

% Calculate SNR in linear scale
snr_linear = noise_free_power / mse;

% Calculate SNR
snr = 10 * log10(snr_linear);

A(isnan(A))=0;B(isnan(B))=0;
% Assuming you have the ssim function from the toolbox
[ssim_value, ~] = ssim(A, B);
end
function anpr=fft_anpr(B, A)

trp=A;trp(isnan(trp))=0;
tmp=B;tmp(isnan(tmp))=0;
fft_data = fft2(trp);
fft_gauss = fft2(tmp);

% Power spectra of original and filtered data
power_spectrum_data = abs(fft_data).^2;
power_spectrum_gauss = abs(fft_gauss).^2;

total_ref_power = sum(power_spectrum_data(:));
total_filtered_power = sum(power_spectrum_gauss(:));
anpr = (total_filtered_power - total_ref_power) / total_ref_power;
end
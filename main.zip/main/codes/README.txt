
-------------------------------------------------------------------------------------------------------------------
Arctic/Antarctic Ocean-Surface Stress Analysis, 2013-2018
-------------------------------------------------i-----------------------------------------------------------------

- This directory contains the basic codes for generating the daily Arctic/Antarctic Ocean-Surface Stress Analysis files:
  README                              This file
  tau_Ekman_cal_arc.m                 core code to synthesize daily Arctic surface stress fields from Polar Pathfinder v4, NSIDC 0051, CLS multi-mission Ocean Altimeter, and OAFLUX wind product
  tau_Ekman_cal_ant.m                 core code to synthesize daily Antarctic surface stress fields from Polar Pathfinder v4, NSIDC 0051, CLS multi-mission Ocean Altimeter, and OAFLUX wind product
  err_adjust.m                        error matrix estimate from Gaussian filter tests and ice-water drag coefficient sensitivity tests
  tau_test.m                          executable test-run for one year (2013). Outputs are in ../test
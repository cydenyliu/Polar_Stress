warning off

t_mon = numel(2003:2020)*12;
yr = reshape(repmat(2003:2020,12,1),1,t_mon);
mon = reshape(repmat(1:12,numel(2003:2020),1)',1,t_mon);
mday = eomday(yr,mon);
root_dir = '/mnt/data/oaflux/data8';
% root_dir = '/Users/chaoliu/noaflux/data8';
load('ref_ant.mat')
% load('ice_arc_0310_geo_mean.mat')
% angc_g_new = cosd(double(lon_g));
% angs_g_new = sind(double(lon_g));
% parameter
De = 20;
ro = 1027.5; ra = 1.25;
Cdi = 0.0055; Cda = 0.00125;
yo = 0;

lat_arc = lat_ao(:,1:250);
lon_arc = lon_ao(:,1:250); lon_arc(lon_arc>180)=lon_arc(lon_arc>180)-360;
lon_df = zeros(size(lon_arc)); lat_df = lon_df;
for ii = 1:250
    aa=pathdist([lat_arc(1,ii);lat_arc(1,ii)],[lon_arc(1,ii);lon_arc(3,ii)] );
    lon_df(:,ii) = aa(2);
    aa=pathdist([lat_arc(1,ii)-0.25;lat_arc(1,ii)+0.25],[lon_arc(1,ii);lon_arc(1,ii)] );
    lat_df(:,ii) = aa(2);
end
type='/oa_ant/'
f_arc = coriolisf(lat_arc);

for yy = [2020 2021]
    yy
    yo = yo + 1;
    dofy = 0;

    % loading lon/lat
 % ice extent
    sub_dir_A = [root_dir '/ice_stress/data/NISE'];
    file_dir_A = [sub_dir_A '/v5/2017/NISE_SSMISF18_20170101.HDFEOS.nc'];
    lat_A = ncread(file_dir_A, 'Latitude_1');
    lon_A = ncread(file_dir_A, 'Longitude_1');

    sub_dir_Ai = [root_dir '/ice_stress/data/NSIDC0051'];
    file_dir_Ai = [sub_dir_Ai '/NSIDC0771_LatLon_PS_S25km_v1.0.nc'];
    lat_Ai = ncread(file_dir_Ai, 'latitude');
    lon_Ai = ncread(file_dir_Ai, 'longitude');

    % ice motion
    sub_dir_im = [root_dir '/ice_stress/data/icemotion_vectors_v4/south/daily'];
    file_dir_im = [sub_dir_im '/icemotion_daily_sh_25km_' num2str(yy) '0101_' num2str(yy) '1231_v4.1.nc'];
    if yo == 1
        lat_i = double(ncread(file_dir_im, 'latitude'));
        lon_i = double(ncread(file_dir_im, 'longitude'));

        % standard
        lon_i = double(lon_i);
        lat_i = double(lat_i);
        lon_standard = lon_i;
        lat_standard = lat_i;
        f = coriolisf(lat_standard);
    end

    angc_g_standard = cosd(lon_standard);
    angs_g_standard = sind(lon_standard);

    % geo vel
    sub_dir_gc = [root_dir '/ice_stress/data/DOT'];
    file_dir_gc = [sub_dir_gc '/Full_DOT_data_Anto.nc'];
    if yo == 1
        lat_g = double(ncread(file_dir_gc, 'lats'));
        lon_g = double(ncread(file_dir_gc, 'lons'));
        angc_g = double(ncread(file_dir_gc, 'ang_c'));
        angs_g = double(ncread(file_dir_gc, 'ang_s'));

        % geostrophic to EASE-grid, current & angle
        lon_g = double(lon_g);
        lat_g = double(lat_g);

angc_g_new = cosd(double(lon_g));
angs_g_new = sind(double(lon_g));

        lon_g_p = lon_g(167,:); 
        lon_g_p = lon_g_p+360;
        lon_g_db = [lon_g_p; lon_g]; 
        lat_g_db = [lat_g(167,:); lat_g];

        % angc_g_db = double([angc_g(167,:); angc_g]);
        % angs_g_db = double([angs_g(167,:); angs_g]);
        % angc_g_db(isnan(angc_g_db)) = 0; 
        % angs_g_db(isnan(angs_g_db)) = 0;
        % angc_g_standard = griddata(lon_g_db, lat_g_db, angc_g_db, lon_standard, lat_standard);
        % angs_g_standard = griddata(lon_g_db, lat_g_db, angs_g_db, lon_standard, lat_standard);

        angc_g_standard = cosd(lon_standard);
        angs_g_standard = sind(lon_standard);

        cs_square = angc_g_standard.^2 + angs_g_standard.^2;
        clear angc_g_db angs_g_db
    end

    % wind
    sub_dir_wnd = [root_dir '/OAwnd_Daily'];
    if yo == 1
        lat_ao = -89.875:0.25:89.875;
        lon_ao = .125:0.25:359.875;
        [lat_ao, lon_ao] = meshgrid(lat_ao, lon_ao);
        % save ref lat_ao lon_ao lat_g_old lon_g_old lat_g lon_g lat_A lon_A lat_i lon_i ...
        %     lat_standard lon_standard angc_g angs_g angc_g_standard angs_g_standard cs_square
        % save par f De Cda Cdi ro ra
    end

    for mm = 1:12
        mm
        dinm = eomday(yy,mm);

        % geo vel
        if yy<2021 &&mm<5
        % file_dir_gc = [sub_dir_gc '/Daily/Ant/' num2str(yy)];
        %     % xx_g_m = load([file_dir_gc '/xx.' num2str(yy) num2str(mm, '%02d') '.mat']);
        %     % yy_g_m = load([file_dir_gc '/yy.' num2str(yy) num2str(mm, '%02d') '.mat']);
        %     dd_g_m = load([file_dir_gc '/dd.' num2str(yy) num2str(mm, '%02d') '.mat']);
        % else
        file_dir_gc = [sub_dir_gc '/Daily/Ant/' num2str(2020)];
            % xx_g_m = load([file_dir_gc '/xx.' num2str(yy) num2str(mm, '%02d') '.mat']);
            % yy_g_m = load([file_dir_gc '/yy.' num2str(yy) num2str(mm, '%02d') '.mat']);
            dd_g_m = load([file_dir_gc '/dd.' num2str(2020) num2str(mm, '%02d') '.mat']);
        else
        file_dir_gc = [sub_dir_gc '/Daily/Ant/' num2str(2019)];
            dd_g_m = load([file_dir_gc '/dd.' num2str(2019) num2str(mm, '%02d') '.mat']);
            
        end

        % wind
        file_dir_wnd = [sub_dir_wnd '/' num2str(yy)];
        uu_ao_m = load([file_dir_wnd '/taux.' num2str(yy) num2str(mm, '%02d') '.mat']);
        vv_ao_m = load([file_dir_wnd '/tauy.' num2str(yy) num2str(mm, '%02d') '.mat']);

        % oa Ek
        filename = ([root_dir, '/OAwnd_Daily/', num2str(yy),'/ek.',...
            num2str(yy), num2str(mm, '%02d'), '.mat']);
        load(filename, 'ek')

        for dd = 1:dinm
            dofy = dofy+1

            % ice extent
            sub_dir_A = [root_dir '/ice_stress/data/NISE'];
            if yy < 2009
                file_dir_A = [sub_dir_A '/v2/' num2str(yy) '/NISE_SSMIF13_'...
                    num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.nc'];
                    Alpha = ncread(file_dir_A, 'Extent_1', [1 1], [inf inf]);
            elseif yy == 2009
                if mm < 10
                    file_dir_A = [sub_dir_A '/v2/' num2str(yy) '/NISE_SSMIF13_'...
                        num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.nc'];
                        Alpha = ncread(file_dir_A, 'Extent_1', [1 1], [inf inf]);
                else
                    file_dir_A = [sub_dir_A '/v4/' num2str(yy) '/NISE_SSMISF17_'...
                        num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.nc'];
                        Alpha = ncread(file_dir_A, 'Extent_1', [1 1], [inf inf]);
                end
            elseif yy < 2016
                file_dir_A = [sub_dir_A '/v4/' num2str(yy) '/NISE_SSMISF17_'...
                    num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.nc'];
                    Alpha = ncread(file_dir_A, 'Extent_1', [1 1], [inf inf]);
            elseif yy==2016
                if mm < 12
                    file_dir_A = [sub_dir_A '/v4/' num2str(yy) '/NISE_SSMISF17_'...
                        num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.nc'];
                        Alpha = ncread(file_dir_A, 'Extent_1', [1 1], [inf inf]);
                else
                    file_dir_A = [sub_dir_A '/v5/' num2str(yy) '/NISE_SSMISF18_'...
                        num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.nc'];
                        Alpha = ncread(file_dir_A, 'Extent_1', [1 1], [inf inf]);
                end
            else
                file_dir_A = [sub_dir_A '/v5/' num2str(yy) '/NISE_SSMISF18_'...
                    num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '.HDFEOS.nc'];
                    Alpha = ncread(file_dir_A, 'Extent_1', [1 1], [inf inf]);
            end

            Alpha = double(Alpha);

            sub_dir_Ai = [root_dir '/ice_stress/data/NSIDC0051'];
            file_dir_Ai = [sub_dir_Ai '/' num2str(yy) '/NSIDC0051_SEAICE_PS_S25km_'...
                num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '_v2.0.nc'];
            Alphai = ncread(file_dir_Ai,'F17_ICECON');
            Alphai = double(Alphai);

            % ice motion
            xx_i = double(ncread(file_dir_im, 'u', [1 1 dofy], [inf inf 1]));
            yy_i = double(ncread(file_dir_im, 'v', [1 1 dofy], [inf inf 1]));

            % % geo vel
            % if yy > 2010
                % xx_g = xx_g_m.xx(:,:,dd);
                % yy_g = yy_g_m.yy(:,:,dd);
                dd_g = dd_g_m.dd(:,:,dd);

                dots=[dd_g;dd_g(106:107,:)];
                dots_a_arc = griddata([lon_g;lon_g(106,:)-360;lon_g(107,:)+360], [lat_g;lat_g(106:107,:)], double(dots), lon_arc, lat_arc);
                gvv_g=9.8*([dots_a_arc(2:end,:);dots_a_arc(1,:)]-[dots_a_arc(end,:);dots_a_arc(1:end-1,:)])./f_arc./lon_df;
                guu_g=-9.8*([dots_a_arc(:,2:end) 2*dots_a_arc(:,end)-dots_a_arc(:,end-1)]-[2*dots_a_arc(:,1)-dots_a_arc(:,2) dots_a_arc(:,1:end-1)])./f_arc./lat_df;
                xx_g = griddata( [lon_arc;lon_arc(720,:)-360;lon_arc(721,:)+360],...
                    [lat_arc;lat_arc(720,:);lat_arc(721,:)], [guu_g;guu_g(720,:);guu_g(721,:)], lon_standard, lat_standard);
                yy_g = griddata( [lon_arc;lon_arc(720,:)-360;lon_arc(721,:)+360],...
                    [lat_arc;lat_arc(720,:);lat_arc(721,:)], [gvv_g;gvv_g(720,:);gvv_g(721,:)], lon_standard, lat_standard);

                % uu_g = xx_g.*angs_g + yy_g.*angc_g;
                % vv_g = xx_g.*angc_g - yy_g.*angs_g;

                % vv_g =-( xx_g.*angc_g_new + yy_g.*angs_g_new);
                % uu_g =-(-xx_g.*angs_g_new + yy_g.*angc_g_new);
            % 
            % else
            %     xx_g = xx_g_m.uu(:,:,dd);
            %     yy_g = yy_g_m.vv(:,:,dd);
            % end

            % wind
            uu_ao = uu_ao_m.taux(:,:,dd);
            vv_ao = vv_ao_m.tauy(:,:,dd);

            % interpolation

            % refit EASE-grid
            % ice motion
            xx_i_standard = xx_i;
            yy_i_standard = yy_i;
            xx_i_standard(isnan(xx_i_standard)) = 0;
            yy_i_standard(isnan(yy_i_standard)) = 0;

            % ice extent
            Alpha_standard = double(fliplr(Alpha(201:end-200,201:end-200)));
            Alpha_standard(Alpha_standard==0) = nan;
            Alpha_standard(Alpha_standard==255) = 0;
            Alpha_standard(Alpha_standard>100) = nan;

            Alphai = Alphai*100;
            Alphai(Alphai>100) = nan;
            lon_Ai_db=[lon_Ai;lon_Ai(159,:)-360;lon_Ai(158,:)+360];
            lat_Ai_db=[lat_Ai;lat_Ai(159,:);lat_Ai(158,:)];
            Alphai=[Alphai;Alphai(159,:);Alphai(158,:)];

            Alpha_standardi = griddata(lon_Ai_db, lat_Ai_db, Alphai, lon_standard, lat_standard);
            Alpha_standardi = round(Alpha_standardi);
            Alpha_standardi(Alpha_standardi>100) = nan;
            Alpha_standardi(isnan(Alpha_standardi)) = Alpha_standard(isnan(Alpha_standardi));
            Alpha_standard = Alpha_standardi;

            % geostrophic to EASE-grid
            xx_g = double(xx_g);
            yy_g = double(yy_g);
            % 
            % if yy > 2010
                xx_g_standard = xx_g;
                yy_g_standard = yy_g;
            %     clear xx_g_db yy_g_db
            % else
            %     xx_g_db = [xx_g(1,:); xx_g];
            %     yy_g_db = [yy_g(1,:); yy_g];
            %     xx_g_db(isnan(xx_g_db)) = 0; yy_g_db(isnan(yy_g_db)) = 0;
            %     xx_g_standard = griddata(lon_g_old_db, lat_g_old_db, xx_g_db, lon_standard, lat_standard);
            %     yy_g_standard = griddata(lon_g_old_db, lat_g_old_db, yy_g_db, lon_standard, lat_standard);
            %     clear xx_g_db yy_g_db
            % end

            % wind stress to EASE-grid
            lon_ao(lon_ao>180) = lon_ao(lon_ao>180)-360;
            lon_ao_p = lon_ao(721,:); lon_ao_p = lon_ao_p+360;
            lon_ao_db = [lon_ao_p; lon_ao]; lat_ao_db = [lat_ao(721,:); lat_ao];
            uu_ao_db = [uu_ao(721,:); uu_ao]; vv_ao_db = [vv_ao(721,:); vv_ao];
            uu_ao_db(isnan(uu_ao_db)) = 0; vv_ao_db(isnan(vv_ao_db)) = 0;
            uu_ao_standard = griddata(lon_ao_db, lat_ao_db, uu_ao_db, lon_standard, lat_standard);
            vv_ao_standard = griddata(lon_ao_db, lat_ao_db, vv_ao_db, lon_standard, lat_standard);
            clear lon_ao_db lat_ao_db tauu_ao_db tauv_ao_db
            % uu_ao_standard=zeros(265);vv_ao_standard=zeros(265);

 % masks
            mask_A = ~isnan(Alpha_standard);
            % mask_i = ~isnan(xx_i_standard) .* ~isnan(xx_i_standard);
            % mask_e = ~isnan(tauu_ao_standard) .* ~isnan(tauv_ao_standard);
            % mask_g = ~isnan(xx_g_standard) .* ~isnan(yy_g_standard);
            mask_standard = double(mask_A);
            mask_standard(mask_standard<1) = nan;
            mask_standard(lat_standard>87.34) = nan;

            % xy to uv
            uu_g_standard = xx_g_standard;
            vv_g_standard = yy_g_standard;
            % ice motion
            uu_i_standard = xx_i_standard.*angc_g_standard - yy_i_standard.*angs_g_standard;
            vv_i_standard = xx_i_standard.*angs_g_standard + yy_i_standard.*angc_g_standard;

                % mask fitting
                wmsk=uu_ao_standard==0;wmsk=logical(wmsk.*mask_A);
                % Alpha
                tmp=Alpha_standard;
                b00=tmp==0;
                tmp(logical(b00.*wmsk))=nan;
                tmp(~mask_A)=0;
                tmp=(fillmissing(tmp,'linear')+(fillmissing(tmp','linear'))')/2;
                tmp(~mask_A)=nan;
                Alpha_standard=tmp;

                % ice motion
                theta_i_standard = atan2(vv_i_standard, uu_i_standard);
                speed_i_standard = sqrt(uu_i_standard.^2 + vv_i_standard.^2);

                tmp=theta_i_standard;tmp(speed_i_standard==0)=0;
                tmp(~mask_A)=nan;
                b00=tmp==0;
                tmp(logical(b00.*wmsk))=nan;
                tmp2=tmp';
                tmp3=fillmissing(tmp(wmsk),'linear');tmp(wmsk)=tmp3;
                tmp3=fillmissing(tmp2(wmsk'),'linear');tmp2(wmsk')=tmp3;
                theta_i_standard=(tmp+tmp2')/2;

                tmp=speed_i_standard;
                tmp(~mask_A)=nan;
                b00=tmp==0;
                tmp(logical(b00.*wmsk))=nan;
                tmp2=tmp';
                tmp3=fillmissing(tmp(mask_A),'linear');tmp(mask_A)=tmp3;
                tmp3=fillmissing(tmp2(mask_A'),'linear');tmp2(mask_A')=tmp3;
                speed_i_standard=(tmp+tmp2')/2;

                speed_i_standard(~mask_A)=0;theta_i_standard(~mask_A)=0;

                uu_i_standard = speed_i_standard .* cos(theta_i_standard);
                vv_i_standard = speed_i_standard .* sin(theta_i_standard);

            % Complex
            % U_g = uu_g_standard+vv_g_standard*1i; %U_g=U_g.*0;% geo or not
            % if dofy<366
            %     U_g = U_g_clim(:,:,dofy)+V_g_clim(:,:,dofy)*1i; 
            % else
            %     U_g = U_g_clim(:,:,365)+V_g_clim(:,:,365)*1i; 
            % end

                U_g = uu_g_standard+vv_g_standard*1i;
            U_i = uu_i_standard+vv_i_standard*1i; U_i = U_i/100; % cm/s to m/s
            % U_g=U_i.*0;
            wnd_e = uu_ao_standard+vv_ao_standard*1i;

            % TAU_e = ra*Cda*abs(wnd_e).*wnd_e;
            TAU_e = wnd_e;

            Alpha_standard_o = Alpha_standard; 
            Alpha_standard_o(isnan(Alpha_standard_o)) = 0;
            U_i(isnan(U_i)) = 0+0*1i;
            U_g(isnan(U_g)) = 0+0*1i;

            % MRIteration
            [TAU, k] = modified_richardson_iteration(0.1, 10^-5, 5000, Alpha_standard_o, TAU_e, U_i, U_g, f, ro, De, Cdi);

            % TAU_i = (TAU - (1-Alpha_standard/100).*TAU_e) ./ (Alpha_standard/100);
            % TAU = TAU .* mask_standard;
            % TAU_i = TAU_i .* mask_standard;
            % TAU_e = TAU_e .* mask_standard;

            
            TAU_output(:,:,dofy) = TAU;
            iteration_k(1,dofy) = k;
            U_i_input(:,:,dofy) = U_i;
            U_g_input(:,:,dofy) = U_g;
            Alpha_input(:,:,dofy) = Alpha_standard;

            femp;
            if mm == 1
                mkdir([root_dir, '/ice_stress/exp/oa_ant/']);
                mkdir([root_dir, '/ice_stress/step_fig/oa_ant/']);
                mkdir([root_dir, '/ice_stress/step_fig/oa_ant/', num2str(yy)]);
                mkdir([root_dir, '/ice_stress/step_fig/oa_ant/', num2str(yy), '/day']);
                mkdir([root_dir, '/ice_stress/step_fig/oa_ant/', num2str(yy), '/ek']);
            end
            figname=strcat(root_dir, '/ice_stress/step_fig/oa_ant/', num2str(yy),'/day/chk.',num2str(yy), num2str(mm, '%02d'), num2str(dd, '%02d'), '.png');
            print(figname,'-dpng')
            
            % Ekman
            ek_o = squeeze(ek(:,1:250,dd));

            xxx = real(TAU)./f/ro; yyy = imag(TAU)./f/ro;
            m_tau = yyy - xxx*1i;

            lon_xxs = [-lon_standard(161,:); lon_standard];
            lat_xxs = [lat_standard(161,:); lat_standard];
            xxx_db = [xxx(161,:); xxx]; yyy_db = [yyy(161,:); yyy];
            xxx_db(isnan(xxx_db)) = 0; yyy_db(isnan(yyy_db)) = 0;
            
            xxx_arc = griddata(lon_xxs, lat_xxs, xxx_db, lon_arc, lat_arc);
            yyy_arc = griddata(lon_xxs, lat_xxs, yyy_db, lon_arc, lat_arc);

            yyy_arc = [yyy_arc(end,:); yyy_arc; yyy_arc(1,:)];

            xxx_arc = [2*xxx_arc(:,1)-xxx_arc(:,2) xxx_arc 2*xxx_arc(:,end)-xxx_arc(:,end-1)];

            xxx_dy = (xxx_arc(:,3:end)-xxx_arc(:,1:end-2))./lat_df;
            yyy_dx = (yyy_arc(3:end,:)-yyy_arc(1:end-2,:))./lon_df;

            ep_tau = yyy_dx - xxx_dy;
            lon_arc_db = [lon_arc(720,:)-360;lon_arc(721,:)+360;lon_arc];
            lat_arc_db = [lat_arc(720,:);lat_arc(721,:);lat_arc];
            ep_tau_db = [ep_tau(720,:);ep_tau(721,:);ep_tau];
            ep_tau = griddata(lon_arc_db, lat_arc_db, ep_tau_db, lon_standard, lat_standard);

            ep_tau_db = [ek_o(720,:);ek_o(721,:);ek_o];
            ep_tau_o = griddata(lon_arc_db, lat_arc_db, ep_tau_db, lon_standard, lat_standard);
            % ep_tau_o = ek_o;
            ep_femp;

            ep_TAU_output(:,:,dofy) = ep_tau;
            figname=strcat(root_dir, '/ice_stress/step_fig/oa_ant/', num2str(yy),'/ek/chk.', num2str(yy), num2str(mm, '%02d'), num2str(dd, '%02d'), '.png');
            print(figname,'-dpng')
            clc
        end
    end

    file=strcat(root_dir, '/ice_stress/exp/oa_ant/tau.',num2str(yy), '.nc');
    if exist(file, 'file')==2
        delete(file);
    end

    tmp_att.long_name='longitude';
    tmp_att.units='degree_east';
    nccreatewrite(file,'lon',{'x','y'},lon_standard,tmp_att)
    tmp_att.long_name='latitude';
    tmp_att.units='degree_north';
    nccreatewrite(file,'lat',{'x','y'},lat_standard,tmp_att)

    tmp_att.long_name='Total Stress U, output';
    tmp_att.units='N·m-2';
    nccreatewrite(file,'TAUU',{'x','y','t'},real(TAU_output),tmp_att)
    tmp_att.long_name='Total Stress V, output';
    tmp_att.units='N·m-2';
    nccreatewrite(file,'TAUV',{'x','y','t'},imag(TAU_output),tmp_att)
    % tmp_att.long_name='Ekman Transport, output';
    % tmp_att.units='m2·s−1';
    % nccreatewrite(file,'m_TAU',{'x','y','t'},m_TAU_output,tmp_att)
    tmp_att.long_name='Ekman Upwelling Rate, output';
    tmp_att.units='m·s−1';
    nccreatewrite(file,'e_TAU',{'x','y','t'},ep_TAU_output,tmp_att)

    tmp_att.long_name='Ice Extent, input';
    tmp_att.units='percentage';
    nccreatewrite(file,'Alpha',{'x','y','t'},Alpha_input,tmp_att)
    tmp_att.long_name='Ice Motion U, input';
    tmp_att.units='m/s';
    nccreatewrite(file,'U_i',{'x','y','t'},real(U_i_input),tmp_att)
    tmp_att.long_name='Geostrophic Velocity U, input';
    tmp_att.units='m/s';
    nccreatewrite(file,'U_g',{'x','y','t'},real(U_g_input),tmp_att)
    tmp_att.long_name='Ice Motion V, input';
    tmp_att.units='m/s';
    nccreatewrite(file,'V_i',{'x','y','t'},imag(U_i_input),tmp_att)
    tmp_att.long_name='Geostrophic Velocity V, input';
    tmp_att.units='m/s';
    nccreatewrite(file,'V_g',{'x','y','t'},imag(U_g_input),tmp_att)
    tmp_att.long_name='Iteration Number';
    tmp_att.units='generic';
    nccreatewrite(file,'iteration',{'t'},iteration_k,tmp_att)
    clear TAU_output m_TAU_output ep_TAU_output Alpha_input U_i_input U_g_input iteration_k
end

%% %% %%
% getting iteration
function [x, k] = modified_richardson_iteration(omega, tol, max_iter, Alpha_standard, TAU_e, U_i, U_g, f, ro, De, Cd)
% A_fun: function handle that returns A based on x
% b: right-hand side vector
% omega: relaxation parameter (0 < omega < 2)
% tol: tolerance for convergence
% max_iter: maximum number of iterations

% Initialize solution vector
x = zeros(size(Alpha_standard));

% Perform modified Richardson iteration
for k = 1:max_iter
    [A, b] = Ab_fun(x, Alpha_standard, TAU_e, U_i, U_g, f, ro, De, Cd); % Compute A & b based on current x
    x_new = x + omega * (b - A .* x);
    % x_new(x_new>10) = nan;
    % Check convergence
    jj = abs(x_new - x);
    % jj (Alpha_standard<15) = nan;
    if max(jj(:)) < tol
        break;
    end

    % Update solution vector
    x = x_new;
end
% fprintf(['Converged in ', num2str(k), ' iterations.'])
end

% getting A & b
function [A, b] = Ab_fun(x, Alpha_standard, TAU_e, U_i, U_g, f, ro, De, Cd)
% Ab_fun: function handle that returns A based on x
Alpha_standard(real(TAU_e)~=0)=100;
% Full function
lhs = 1;
rhs2 = (1-Alpha_standard/100).*TAU_e;
U_e = (sqrt(2)*exp(-1i*pi/4)./(f*ro*De)).*x;
U_r = U_i - (U_e + U_g); a_U_r = abs(U_r);
% rhs1_0 = -ro*Cd*a_U_r.*U_e;
rhs1_1 = ro*Cd*a_U_r.*(U_i - U_g).*Alpha_standard/100;
% Reassemble
A = lhs+ro*Cd*a_U_r.*(sqrt(2)*exp(-1i*pi/4)./(f*ro*De)).*Alpha_standard/100;
b = rhs1_1+rhs2;
end
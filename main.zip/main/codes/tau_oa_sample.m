warning off

t_mon = numel(2003:2020)*12;
yr = reshape(repmat(2003:2020,12,1),1,t_mon);
mon = reshape(repmat(1:12,numel(2003:2020),1)',1,t_mon);
mday = eomday(yr,mon);
root_dir = '/mnt/data/oaflux/data8'; % root folder

% parameter
De = 20;
ro = 1027.5; ra = 1.25;
Cdi = 0.0055;

for yy = 2011
    dofy = 0;

    % loading lon/lat

    % ice extent
    sub_dir_Ai = [root_dir '/ice_stress/data/NSIDC0051'];
    file_dir_Ai = [sub_dir_Ai '/NSIDC0771_LatLon_PS_N25km_v1.0.nc'];
    lat_Ai = ncread(file_dir_Ai, 'latitude');
    lon_Ai = ncread(file_dir_Ai, 'longitude');

    % ice motion
    sub_dir_im = [root_dir '/ice_stress/data/icemotion_vectors_v4/north/daily'];
    file_dir_im = [sub_dir_im '/icemotion_daily_nh_25km_' num2str(yy) '0101_' num2str(yy) '1231_v4.1.nc'];
    if yo == 1
        lat_i = double(ncread(file_dir_im, 'latitude'));
        lon_i = double(ncread(file_dir_im, 'longitude'));

        % standard
        lon_i = double(lon_i);
        lat_i = double(lat_i);
        lon_standard = lon_i(49:end-48,49:end-48);
        lat_standard = lat_i(49:end-48,49:end-48);
        f = coriolisf(lat_standard);
    end

    % wind
    sub_dir_wnd = [root_dir '/OAwnd_Daily'];
    if yo == 1
        lat_oa = -89.875:0.25:89.875;
        lon_oa = .125:0.25:359.875;
        [lat_oa, lon_oa] = meshgrid(lat_oa, lon_oa);
    end

    for mm = 1:12
        dinm = eomday(yy,mm);

        % wind
        file_dir_wnd = [sub_dir_wnd '/' num2str(yy)];
        uu_oa_m = load([file_dir_wnd '/taux.' num2str(yy) num2str(mm, '%02d') '.mat']);
        vv_oa_m = load([file_dir_wnd '/tauy.' num2str(yy) num2str(mm, '%02d') '.mat']);


        for dd = 1:dinm
            dofy = dofy+1;


            % ice extent
            sub_dir_Ai = [root_dir '/ice_stress/data/NSIDC0051'];
            file_dir_Ai = [sub_dir_Ai '/' num2str(yy) '/NSIDC0051_SEAICE_PS_N25km_'...
                num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '_v2.0.nc'];
            if yy<1991
                vari='F08_ICECON';
            elseif yy==1991 && dofy<365-12
                vari='F08_ICECON';
            elseif yy<1995
                vari='F11_ICECON';
            elseif yy==1995 && dofy<273
                vari='F11_ICECON';
            elseif yy<2008
                vari='F13_ICECON';
            else
                vari='F17_ICECON';
            end
            id=0;
            try
                Alphai = ncread(file_dir_Ai,vari);
            catch exception
                Alphai = nan(304,448);id=1;
            end

            % ice motion
            xx_i = double(ncread(file_dir_im, 'u', [1 1 dofy], [inf inf 1]));
            yy_i = double(ncread(file_dir_im, 'v', [1 1 dofy], [inf inf 1]));

            % wind
            uu_oa = uu_oa_m.taux(:,:,dd);
            vv_oa = vv_oa_m.tauy(:,:,dd);

            % interpolation

            % refit EASE-grid
            % ice motion
            xx_i_standard = xx_i(49:end-48,49:end-48);
            yy_i_standard = yy_i(49:end-48,49:end-48);
            xx_i_standard(isnan(xx_i_standard)) = 0;
            yy_i_standard(isnan(yy_i_standard)) = 0;

            % ice extent

            Alphai = Alphai*100;
            Alphai(Alphai>100) = nan;
            lon_Ai(:,449)=lon_Ai(:,448);
            lat_Ai(:,449)=lat_Ai(:,448);
            Alphai(:,449)=Alphai(:,448);
            for ii=1:154
                lon_Ai(ii,449)=-lon_Ai(ii,ii+80);
                lat_Ai(ii,449)=lat_Ai(ii,ii+80);
                Alphai(ii,449)=Alphai(ii,ii+80);
            end
            Alpha_standardi = griddata(lon_Ai, lat_Ai, Alphai, lon_standard, lat_standard);
            Alpha_standardi = round(Alpha_standardi);
            Alpha_standardi(Alpha_standardi>100) = nan;

            if id==1
                Alpha_standardi(xx_i_standard~=0)=100;
                Alpha_standardi(xx_i_standard==0)=0;
            end

            Alpha_standard = Alpha_standardi;

            % wind stress to EASE-grid
            lon_oa(lon_oa>180) = lon_oa(lon_oa>180)-360;
            lon_oa_p = lon_oa(721,:); lon_oa_p = lon_oa_p+360;
            lon_oa_db = [lon_oa_p; lon_oa]; lat_oa_db = [lat_oa(721,:); lat_oa];
            uu_oa_db = [uu_oa(721,:); uu_oa]; vv_oa_db = [vv_oa(721,:); vv_oa];
            uu_oa_db(isnan(uu_oa_db)) = 0; vv_oa_db(isnan(vv_oa_db)) = 0;
            uu_oa_standard = griddata(lon_oa_db, lat_oa_db, uu_oa_db, lon_standard, lat_standard);
            vv_oa_standard = griddata(lon_oa_db, lat_oa_db, vv_oa_db, lon_standard, lat_standard);
            clear lon_oa_db lat_oa_db tauu_oa_db tauv_oa_db

            % ice motion
            uu_i_standard = xx_i_standard.*angc_g_standard + yy_i_standard.*angs_g_standard;
            vv_i_standard =-xx_i_standard.*angs_g_standard + yy_i_standard.*angc_g_standard;

            % masks
            mask_A = ~isnan(Alpha_standard);
            mask_standard = double(mask_A);
            mask_standard(mask_standard<1) = nan;
            mask_standard(lat_standard>87.34) = nan;

            % Complex
            if dofy<366
                U_g = U_g_clim(:,:,dofy)+V_g_clim(:,:,dofy)*1i;
            else
                U_g = U_g_clim(:,:,365)+V_g_clim(:,:,365)*1i;
            end
            U_i = uu_i_standard+vv_i_standard*1i; U_i = U_i/100; % cm/s to m/s
            wnd_e = uu_oa_standard+vv_oa_standard*1i;
            TAU_e = wnd_e;

            Alpha_standard_o = Alpha_standard;
            Alpha_standard_o(isnan(Alpha_standard_o)) = 0;
            U_i(isnan(U_i)) = 0+0*1i;
            U_g(isnan(U_g)) = 0+0*1i;

            % MRIteration
            [TAU, k] = modified_richardson_iteration(0.1, 10^-5, 5000, Alpha_standard_o, TAU_e, U_i, U_g, f, ro, De, Cdi);

        end
    end
end

%% %% %%
% getting iteration
function [x, k] = modified_richardson_iteration(omega, tol, max_iter, Alpha_standard, TAU_e, U_i, U_g, f, ro, De, Cd)
% A_fun: function handle that returns A based on x
% b: right-hand side vector
% omega: relaxation parameter (0 < omega < 2)
% tol: tolerance for convergence
% max_iter: maximum number of iterations

% Initialize solution vector
x = zeros(size(Alpha_standard));

% Perform modified Richardson iteration
for k = 1:max_iter
    [A, b] = Ab_fun(x, Alpha_standard, TAU_e, U_i, U_g, f, ro, De, Cd); % Compute A & b based on current x
    x_new = x + omega * (b - A .* x);
    % x_new(x_new>10) = nan;
    % Check convergence
    jj = abs(x_new - x);
    % jj (Alpha_standard<15) = nan;
    if max(jj(:)) < tol
        break;
    end

    % Update solution vector
    x = x_new;
end
% fprintf(['Converged in ', num2str(k), ' iterations.'])
end

% getting A & b
function [A, b] = Ab_fun(x, Alpha_standard, TAU_e, U_i, U_g, f, ro, De, Cd)
% Ab_fun: function handle that returns A based on x
% Full function
lhs = 1;
Alpha_standard(Alpha_standard>=15)=100;Alpha_standard(Alpha_standard<15)=0;
rhs2 = (1-Alpha_standard/100).*TAU_e;
U_e = (sqrt(2)*exp(-1i*pi/4)./(f*ro*De)).*x;
U_r = U_i - (U_e + U_g); a_U_r = abs(U_r);
% rhs1_0 = -ro*Cd*a_U_r.*U_e;
rhs1_1 = ro*Cd*a_U_r.*(U_i - U_g).*Alpha_standard/100;
% Reassemble
A = lhs+ro*Cd*a_U_r.*(sqrt(2)*exp(-1i*pi/4)./(f*ro*De)).*Alpha_standard/100;
b = rhs1_1+rhs2;
end
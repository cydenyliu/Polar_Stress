warning off

root_dir = '/mnt/data/oaflux/data8';
load('ref.mat')
load('tau.mat')
% parameter
De = 20;
ro = 1027.5; ra = 1.25;
Cdi = 0.0055; Cda = 0.00125;
yo = 0;
sgm=3;

lat_ao = -89.875:0.25:89.875;
lon_ao = .125:0.25:359.875;
[lat_ao, lon_ao] = meshgrid(lat_ao, lon_ao);
lon_ao(lon_ao>180) = lon_ao(lon_ao>180)-360;

lat_arc = lat_ao(:,548:end);
lon_arc = lon_ao(:,548:end); lon_arc(lon_arc>180)=lon_arc(lon_arc>180)-360;
lon_df = zeros(size(lon_arc)); lat_df = lon_df;
for ii = 1:173
    aa=pathdist([lat_arc(1,ii);lat_arc(1,ii)],[lon_arc(1,ii);lon_arc(3,ii)] );
    lon_df(:,ii) = aa(2);
    aa=pathdist([lat_arc(1,ii)-0.25;lat_arc(1,ii)+0.25],[lon_arc(1,ii);lon_arc(1,ii)] );
    lat_df(:,ii) = aa(2);
end

yy=2011;
% standard
f = coriolisf(lat_standard);

dofy=0;
for mm = 1:12
    dinm = eomday(yy,mm);
    for dd = 1:dinm
        dofy = dofy+1;
        TAU=tau_output(:,:,dofy);

        % Ekman

        xxx = real(TAU)./f/ro; yyy = imag(TAU)./f/ro;
        m_tau = yyy - xxx*1i;

        lon_xxs = [-lon_standard(133,:); lon_standard];
        lat_xxs = [lat_standard(133,:); lat_standard];
        xxx_db = [xxx(133,:); xxx]; yyy_db = [yyy(133,:); yyy];
        % xxx_db(isnan(xxx_db)) = 0; yyy_db(isnan(yyy_db)) = 0;
        xxx_arc = griddata(lon_xxs, lat_xxs, xxx_db, lon_arc, lat_arc);
        yyy_arc = griddata(lon_xxs, lat_xxs, yyy_db, lon_arc, lat_arc);

        yyy_arc = [yyy_arc(end,:); yyy_arc; yyy_arc(1,:)];

        xxx_arc = [2*xxx_arc(:,1)-xxx_arc(:,2) xxx_arc 2*xxx_arc(:,end)-xxx_arc(:,end-1)];

        xxx_dy = (xxx_arc(:,3:end)-xxx_arc(:,1:end-2))./lat_df;
        yyy_dx = (yyy_arc(3:end,:)-yyy_arc(1:end-2,:))./lon_df;

        ep_tau = yyy_dx - xxx_dy;

        lon_arc_db = [lon_arc(720,:)-360;lon_arc(721,:)+360;lon_arc];
        lat_arc_db = [lat_arc(720,:);lat_arc(721,:);lat_arc];
        ep_tau_db = [ep_tau(720,:);ep_tau(721,:);ep_tau];
        ep_tau = griddata(lon_arc_db, lat_arc_db, ep_tau_db, lon_standard, lat_standard);

        % ep_femp_v2;

        m_TAU_output(:,:,dofy) = m_tau;
        ep_TAU_output(:,:,dofy) = ep_tau;
        clc
    end
end

save ekm ep_TAU_output m_TAU_output
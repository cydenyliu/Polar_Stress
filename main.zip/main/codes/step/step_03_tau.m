root_dir = '/mnt/data/oaflux/data8';
load('ref.mat')
load('vel.mat')
load('U_geo.mat')
% parameter
De = 20;
ro = 1027.5; ra = 1.25;
Cdi = 0.0055; Cda = 0.00125;
yo = 0;
sgm=3;

lat_ao = -89.875:0.25:89.875;
lon_ao = .125:0.25:359.875;
[lat_ao, lon_ao] = meshgrid(lat_ao, lon_ao);
lon_ao(lon_ao>180) = lon_ao(lon_ao>180)-360;
yy=2011;
% standard
f = coriolisf(lat_standard);
angc_g_standard = cosd(lon_standard);
angs_g_standard = sind(lon_standard);
dofy=0;
for mm = 1:12
    dinm = eomday(yy,mm);
    for dd = 1:dinm
        dofy = dofy+1;
        % masks
        mask_A = ~isnan(SIC_Alpha(:,:,dofy));
        mask_standard = double(mask_A);
        mask_standard(mask_standard<1) = nan;
        mask_standard(lat_standard>87.34) = nan;
        % regroup
        U_g = U_geo(:,:,dofy); % cm/s to m/s
        U_i = U_ice(:,:,dofy)/100; % cm/s to m/s

        % TAU_e
        TAU_e = U_wnd(:,:,dofy);

        Alpha_standard_o = Alpha_standard;
        Alpha_standard_o(isnan(Alpha_standard_o)) = 0;
        U_i(isnan(U_i)) = 0+0*1i;
        U_g(isnan(U_g)) = 0+0*1i;

        % MRIteration
        [TAU, k] = modified_richardson_iteration(0.1, 10^-5, 5000, Alpha_standard_o, TAU_e, U_i, U_g, f, ro, De, Cdi);

        tau_output(:,:,dofy) = TAU;
        clc
    end
end
save tau tau_output
%% %% %%
% getting iteration
function [x, k] = modified_richardson_iteration(omega, tol, max_iter, Alpha_standard, TAU_e, U_i, U_g, f, ro, De, Cd)
% A_fun: function handle that returns A based on x
% b: right-hand side vector
% omega: relaxation parameter (0 < omega < 2)
% tol: tolerance for convergence
% max_iter: maximum number of iterations

% Initialize solution vector
x = zeros(size(Alpha_standard));

% Perform modified Richardson iteration
for k = 1:max_iter
    [A, b] = Ab_fun(x, Alpha_standard, TAU_e, U_i, U_g, f, ro, De, Cd); % Compute A & b based on current x
    x_new = x + omega * (b - A .* x);
    % x_new(x_new>10) = nan;
    % Check convergence
    jj = abs(x_new - x);
    if max(jj(:)) < tol
        break;
    end

    % Update solution vector
    x = x_new;
end
% fprintf(['Converged in ', num2str(k), ' iterations.'])
end

% getting A & b
function [A, b] = Ab_fun(x, Alpha_standard, TAU_e, U_i, U_g, f, ro, De, Cd)
Alpha_standard(real(TAU_e)~=0)=100;

% Ab_fun: function handle that returns A based on x
% Full function
lhs = 1;
rhs2 = (1-Alpha_standard/100).*TAU_e;
U_e = (sqrt(2)*exp(-1i*pi/4)./(f*ro*De)).*x;
U_r = U_i - (U_e + U_g); a_U_r = abs(U_r);
% rhs1_0 = -ro*Cd*a_U_r.*U_e;
rhs1_1 = ro*Cd*a_U_r.*(U_i - U_g).*Alpha_standard/100;
% Reassemble
A = lhs+ro*Cd*a_U_r.*(sqrt(2)*exp(-1i*pi/4)./(f*ro*De)).*Alpha_standard/100;
b = rhs1_1+rhs2;
end

% clear;
addpath(genpath('../../supp_script/'))
addpath(genpath('../../supp_matrix/'))
% bty=2011;
for jj=bty%:2018
    jj
    % drag
    addlst='../../ice_drag/Arctic/';
    d_tx=[];d_ty=[];
    for ii=[1:10]
        ii
        d_tx(:,:,:,ii)=ncread([addlst num2str(ii, '%02d') '/tau.' num2str(jj) '.nc'],'TAUU');
        d_ty(:,:,:,ii)=ncread([addlst num2str(ii, '%02d') '/tau.' num2str(jj) '.nc'],'TAUV');
    end
    d_tx=std(d_tx,1,4);
    d_ty=std(d_ty,1,4);
    d_tx=fillmissing(d_tx,'linear');
    d_ty=fillmissing(d_ty,'linear');
    % d_tx(:,:,366)=mean(d_tx,3);
    % d_ty(:,:,366)=mean(d_ty,3);
    % d_tx=fillmissing(d_tx,'linear');
    % d_ty=fillmissing(d_ty,'linear');
    addxyt=['../../input_data/icemotion_vectors_v4/north/daily/'];
    % filter
    addlst={'../../gaussian_filt/Arctic/1x1/';...
        '../../gaussian_filt/Arctic/4x4/';...
        '../../gaussian_filt/Arctic/6x6/';...
        '../../gaussian_filt/Arctic/8x8/';...
        '../../gaussian_filt/Arctic/10x10/';...
        '../../experiments/CPOM_test/oa/'};


    e_tx=[];e_ty=[];e_ep=[];
    for ii=[1 2 4 5 6 3]
        e_tx(:,:,:,ii)=ncread([addlst{ii} 'tau.' num2str(jj, '%02d') '.nc'],'TAUU');
        e_ty(:,:,:,ii)=ncread([addlst{ii} 'tau.' num2str(jj, '%02d') '.nc'],'TAUV');
        e_tx(:,:,:,ii)=fillmissing(e_tx(:,:,:,ii),'linear');
        e_ty(:,:,:,ii)=fillmissing(e_ty(:,:,:,ii),'linear');
    end
    kk=size(e_tx,3);

    e_tx=fillmissing(e_tx,'linear');f_tx=std(e_tx,1,4);
    e_ty=fillmissing(e_ty,'linear');f_ty=std(e_ty,1,4);

    e_tx=sqrt(std(e_tx,1,4).^2/6+d_tx(:,:,1:kk).^2/10);
    e_ty=sqrt(std(e_ty,1,4).^2/6+d_ty(:,:,1:kk).^2/10);

    e_tx=fillmissing(e_tx,'linear');
    e_ty=fillmissing(e_ty,'linear');

    x=ncread([addxyt 'icemotion_daily_nh_25km_' num2str(jj, '%02d') '0101_'...
        num2str(jj, '%02d') '1231_v4.1.nc'],'x');x=x(49:end-48);
    y=ncread([addxyt 'icemotion_daily_nh_25km_' num2str(jj, '%02d') '0101_'...
        num2str(jj, '%02d') '1231_v4.1.nc'],'y');y=y(49:end-48);
    time=ncread([addxyt 'icemotion_daily_nh_25km_' num2str(jj, '%02d') '0101_'...
        num2str(jj, '%02d') '1231_v4.1.nc'],'time');
    crs=ncread([addxyt 'icemotion_daily_nh_25km_' num2str(jj, '%02d') '0101_'...
        num2str(jj, '%02d') '1231_v4.1.nc'],'crs');

    file=strcat([addlst{ii} 'tau.' num2str(jj, '%02d') '.nc']);
    lon=ncread(file,'lon');
    lat=ncread(file,'lat');
    TAUU=ncread(file,'TAUU');
    TAUV=ncread(file,'TAUV');
    e_TAU=ncread(file,'e_TAU');
    Alpha=ncread(file,'Alpha');Alpha=double(isnan(Alpha));
    TAUU(isnan(Alpha))=nan;TAUV(isnan(Alpha))=nan;e_TAU(isnan(Alpha))=nan;
    TAUU(TAUU==0)=nan;TAUV(TAUV==0)=nan;e_TAU(e_TAU==0)=nan;
    e_tx(isnan(TAUU))=nan;e_ty(isnan(TAUV))=nan;
    TAU=sqrt(TAUU.^2 + TAUV.^2);


    file=strcat('../test/Arctic/Stress/WHOI_OAFlux_Arctic_Surface_Stress_v1_',num2str(jj), '.nc');
if isfile(file), delete(file); end % Remove file if it exists

% Step 1: Define and write CRS (Coordinate Reference System) information
crs_var = 'crs';
nccreate(file, crs_var, 'DataType', 'int32');
tmp_att.grid_mapping_name = 'lambert_azimuthal_equal_area';
tmp_att.latitude_of_projection_origin = 90.0; % Change to -90.0 for Southern Hemisphere
tmp_att.longitude_of_projection_origin = 0.0;
tmp_att.false_easting = 0.0;
tmp_att.false_northing = 0.0;
tmp_att.semi_major_axis = 6378137.0; % WGS 84 spheroid
tmp_att.inverse_flattening = 298.257223563; % WGS 84 ellipsoid
tmp_att.long_name = 'EASEgrid_N25km';
tmp_att.srid = 'urn:ogc:def:crs:EPSG::3408';
tmp_att.proj4text = '+proj=laea +lat_0=90 +lon_0=0 +x_0=0 +y_0=0 +a=6371228 +b=6371228 +units=m +no_defs';
tmp_att.datum = 'WGS84';
tmp_att.prime_meridian = 'Greenwich';

tmp_att.crs_wkt  = 'PROJCS["NSIDC EASE-Grid North",GEOGCS["Unspecified datum based upon the International 1924 Authalic Sphere",DATUM["Not_specified_based_on_International_1924_Authalic_Sphere",SPHEROID["International 1924 Authalic Sphere",6371228,0,AUTHORITY["EPSG","7057"]],AUTHORITY["EPSG","6053"]],PRIMEM["Greenwich",0,AUTHORITY["EPSG","8901"]],UNIT["degree",0.01745329251994328,AUTHORITY["EPSG","9122"]],AUTHORITY["EPSG","4053"]],UNIT["metre",1,AUTHORITY["EPSG","9001"]],PROJECTION["Lambert_Azimuthal_Equal_Area"],PARAMETER["latitude_of_center",90],PARAMETER["longitude_of_center",0],PARAMETER["false_easting",0],PARAMETER["false_northing",0],AUTHORITY["EPSG","3408"],AXIS["X",UNKNOWN],AXIS["Y",UNKNOWN]]';
for fn = fieldnames(tmp_att)'
    ncwriteatt(file, crs_var, fn{1}, tmp_att.(fn{1}));
end

% Step 2: Add projection variables with compression and fillValue
tmp_att.long_name = 'projection_x_coordinate';
tmp_att.units = 'meters';
tmp_att.FillValue = -9999; % Adding fillValue for missing data
tmp_att.DeflateLevel = 4; % Apply compression
nccreate(file, 'x', 'Dimensions', {'x', length(x)}, 'Datatype', 'double');
ncwrite(file, 'x', x);
ncwriteatt(file, 'x', 'standard_name', tmp_att.long_name);
ncwriteatt(file, 'x', 'units', tmp_att.units);
ncwriteatt(file, 'x', 'coverage_content_type', 'coordinate');
ncwriteatt(file, 'x', 'long_name', 'x');
ncwriteatt(file, 'x', 'axis', 'X');
ncwriteatt(file, 'x', 'grid_mapping', crs_var);

tmp_att.long_name = 'projection_y_coordinate';
tmp_att.units = 'meters';
nccreate(file, 'y', 'Dimensions', {'y', length(y)}, 'Datatype', 'double');
ncwrite(file, 'y', y);
ncwriteatt(file, 'y', 'standard_name', tmp_att.long_name);
ncwriteatt(file, 'y', 'units', tmp_att.units);
ncwriteatt(file, 'y', 'coverage_content_type', 'coordinate');
ncwriteatt(file, 'y', 'long_name', 'y');
ncwriteatt(file, 'y', 'axis', 'Y');
ncwriteatt(file, 'y', 'grid_mapping', crs_var);

% Step 3: Define time as int-encoded datetime
tmp_att.long_name = 'time';
tmp_att.units = 'days since 1970-01-01';
tmp_att.FillValue = -9999;
time_encoded = int32(time); % Convert to integer days
nccreate(file, 'time', 'Dimensions', {'time', length(time)}, 'Datatype', 'int32');
ncwrite(file, 'time', time_encoded);
ncwriteatt(file, 'time', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'time', 'units', tmp_att.units);

% Step 4: Write geographic variables (longitude and latitude)
tmp_att.long_name = 'longitude';
tmp_att.units = 'degree_east';
nccreate(file, 'lon', 'Dimensions', {'x', 'y'}, 'DeflateLevel', tmp_att.DeflateLevel);
ncwrite(file, 'lon', lon);
ncwriteatt(file, 'lon', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'lon', 'units', tmp_att.units);
ncwriteatt(file, 'lon', 'grid_mapping', crs_var);

tmp_att.long_name = 'latitude';
tmp_att.units = 'degree_north';
nccreate(file, 'lat', 'Dimensions', {'x', 'y'}, 'DeflateLevel', tmp_att.DeflateLevel);
ncwrite(file, 'lat', lat);
ncwriteatt(file, 'lat', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'lat', 'units', tmp_att.units);
ncwriteatt(file, 'lat', 'grid_mapping', crs_var);

% Step 5: Land mask with compression and fillValue
tmp_att.long_name = 'Land Mask, 1 for land, 0 for ocean';
tmp_att.units = '';
nccreate(file, 'land_msk', 'Dimensions', {'x', 'y', 'time'}, 'Datatype', 'int8', 'DeflateLevel', tmp_att.DeflateLevel);
ncwrite(file, 'land_msk', int8(Alpha));
ncwriteatt(file, 'land_msk', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'land_msk', 'grid_mapping', crs_var);

% Step 6: Ocean stress variables (apply scaling and fillValue)
scale_factor = 1e-6; % Scaling for precision


% Ocean-Surface Stress
tmp_att.long_name = 'Ocean-Surface Stress';
tmp_att.units = 'N·m-2';
add_offset_TAU = mean(TAU, 'all','omitnan');
nccreate(file, 'TAU', 'Dimensions', {'x', 'y', 'time'}, 'Datatype', 'int32', 'DeflateLevel', tmp_att.DeflateLevel, 'FillValue', tmp_att.FillValue);
tmp=int32((TAU - add_offset_TAU) / scale_factor);tmp(tmp==0)=-9999;
ncwrite(file, 'TAU', tmp);
ncwriteatt(file, 'TAU', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'TAU', 'units', tmp_att.units);
ncwriteatt(file, 'TAU', 'scale_factor', scale_factor);
ncwriteatt(file, 'TAU', 'add_offset', add_offset_TAU);
ncwriteatt(file, 'TAU', 'grid_mapping', crs_var);

% Ocean-Surface Stress (zonal component)
tmp_att.long_name = 'Ocean-Surface Stress, zonal component';
tmp_att.units = 'N·m-2';
add_offset_TAUx = mean(TAUU(:), 'all','omitnan');
nccreate(file, 'TAUx', 'Dimensions', {'x', 'y', 'time'}, 'Datatype', 'int32', 'DeflateLevel', tmp_att.DeflateLevel, 'FillValue', tmp_att.FillValue);
tmp=int32((TAUU - add_offset_TAUx) / scale_factor);tmp(tmp==0)=-9999;
ncwrite(file, 'TAUx', tmp);
ncwriteatt(file, 'TAUx', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'TAUx', 'units', tmp_att.units);
ncwriteatt(file, 'TAUx', 'scale_factor', scale_factor);
ncwriteatt(file, 'TAUx', 'add_offset', add_offset_TAUx);
ncwriteatt(file, 'TAUx', 'grid_mapping', crs_var);

% Ocean-Surface Stress (meridional component)
tmp_att.long_name = 'Ocean-Surface Stress, meridional component';
tmp_att.units = 'N·m-2';
add_offset_TAUy = mean(TAUV(:), 'all','omitnan');
nccreate(file, 'TAUy', 'Dimensions', {'x', 'y', 'time'}, 'Datatype', 'int32', 'DeflateLevel', tmp_att.DeflateLevel, 'FillValue', tmp_att.FillValue);
tmp=int32((TAUV - add_offset_TAUy) / scale_factor);tmp(tmp==0)=-9999;
ncwrite(file, 'TAUy', tmp);
ncwriteatt(file, 'TAUy', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'TAUy', 'units', tmp_att.units);
ncwriteatt(file, 'TAUy', 'scale_factor', scale_factor);
ncwriteatt(file, 'TAUy', 'add_offset', add_offset_TAUy);
ncwriteatt(file, 'TAUy', 'grid_mapping', crs_var);

% Uncertainty estimates for TAUx
tmp_att.long_name = 'uncertainty estimate, TAUx';
tmp_att.units = 'N·m-2';
add_offset_e_TAUx = mean(e_tx(:), 'all','omitnan');
nccreate(file, 'e_TAUx', 'Dimensions', {'x', 'y', 'time'}, 'Datatype', 'int32', 'DeflateLevel', tmp_att.DeflateLevel, 'FillValue', tmp_att.FillValue);
tmp=int32((e_tx - add_offset_e_TAUx) / scale_factor);tmp(tmp==0)=-9999;
ncwrite(file, 'e_TAUx', tmp);
ncwriteatt(file, 'e_TAUx', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'e_TAUx', 'units', tmp_att.units);
ncwriteatt(file, 'e_TAUx', 'scale_factor', scale_factor);
ncwriteatt(file, 'e_TAUx', 'add_offset', add_offset_e_TAUx);
ncwriteatt(file, 'e_TAUx', 'grid_mapping', crs_var);

% Uncertainty estimates for TAUy
tmp_att.long_name = 'uncertainty estimate, TAUy';
tmp_att.units = 'N·m-2';
add_offset_e_TAUy = mean(e_ty(:), 'all','omitnan');
nccreate(file, 'e_TAUy', 'Dimensions', {'x', 'y', 'time'}, 'Datatype', 'int32', 'DeflateLevel', tmp_att.DeflateLevel, 'FillValue', tmp_att.FillValue);
tmp=int32((e_ty - add_offset_e_TAUy) / scale_factor);tmp(tmp==0)=-9999;
ncwrite(file, 'e_TAUy', tmp);
ncwriteatt(file, 'e_TAUy', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'e_TAUy', 'units', tmp_att.units);
ncwriteatt(file, 'e_TAUy', 'scale_factor', scale_factor);
ncwriteatt(file, 'e_TAUy', 'add_offset', add_offset_e_TAUy);
ncwriteatt(file, 'e_TAUy', 'grid_mapping', crs_var);

% Ocean stress variables
scale_factor = 1e-12; % Scaling for precision

% Ekman Pumping Rate
tmp_att.long_name = 'Ekman Pumping Rate, positive is upwelling, negative is downwelling';
tmp_att.units = 'm·s−1';
add_offset_We = mean(e_TAU(:), 'all','omitnan');
nccreate(file, 'We', 'Dimensions', {'x', 'y', 'time'}, 'Datatype', 'int32', 'DeflateLevel', tmp_att.DeflateLevel, 'FillValue', tmp_att.FillValue);
tmp=int32((e_TAU - add_offset_We) / scale_factor);tmp(tmp==0)=-9999;
ncwrite(file, 'We', tmp);
ncwriteatt(file, 'We', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'We', 'units', tmp_att.units);
ncwriteatt(file, 'We', 'scale_factor', scale_factor);
ncwriteatt(file, 'We', 'add_offset', add_offset_We);
ncwriteatt(file, 'We', 'grid_mapping', crs_var);

% Step 9: Global attributes (title, conventions, source)
ncwriteatt(file, "/", "title", "Satellite-based Surface Stress in the Arctic Ocean");
ncwriteatt(file, "/", "Conventions", "CF-1.8");
ncwriteatt(file, "/", "source", "Chao Liu, chao.liu@whoi.edu");

if jj>2012

    addlst='../../ice_drag/Antarctic/';
    d_tx=[];d_ty=[];
    for ii=[1:10]
        ii
        tmp1=ncread([addlst num2str(ii, '%02d') '/tau.' num2str(jj) '.nc'],'TAUU');
        tmp2=ncread([addlst num2str(ii, '%02d') '/tau.' num2str(jj) '.nc'],'TAUV');
        d_tx(:,:,:,ii)=fillmissing(tmp1,'linear');
        d_ty(:,:,:,ii)=fillmissing(tmp2,'linear');
    end
    d_tx=std(d_tx,1,4);
    d_ty=std(d_ty,1,4);
    d_tx=fillmissing(d_tx,'linear');
    d_ty=fillmissing(d_ty,'linear');
    % d_tx(:,:,366)=mean(d_tx,3);
    % d_ty(:,:,366)=mean(d_ty,3);
    % d_tx=fillmissing(d_tx,'linear');
    % d_ty=fillmissing(d_ty,'linear');
    addxyt=['../../input_data/icemotion_vectors_v4/south/daily/'];
    % filter
    addlst={'../../gaussian_filt/Antarctic/1x1/';...
        '../../gaussian_filt/Antarctic/4x4/';...
        '../../gaussian_filt/Antarctic/6x6/';...
        '../../gaussian_filt/Antarctic/8x8/';...
        '../../gaussian_filt/Antarctic/10x10/';...
        '../../experiments/CPOM_test/oa_ant/'};


    e_tx=[];e_ty=[];e_ep=[];
    for ii=[1 2 4 5 6 3]
        tmp1=ncread([addlst{ii} 'tau.' num2str(jj, '%02d') '.nc'],'TAUU');
        tmp2=ncread([addlst{ii} 'tau.' num2str(jj, '%02d') '.nc'],'TAUV');
        tmp1(isinf(tmp1))=0;tmp2(isinf(tmp2))=0;
        e_tx(:,:,:,ii)=fillmissing(tmp1,'linear');
        e_ty(:,:,:,ii)=fillmissing(tmp2,'linear');
    end
    kk=size(e_tx,3);

    e_tx=fillmissing(e_tx,'linear');f_tx=std(e_tx,1,4);
    e_ty=fillmissing(e_ty,'linear');f_ty=std(e_ty,1,4);

    e_tx=sqrt(std(e_tx,1,4).^2/6+d_tx(:,:,1:kk).^2/10);
    e_ty=sqrt(std(e_ty,1,4).^2/6+d_ty(:,:,1:kk).^2/10);

    e_tx=fillmissing(e_tx,'linear');
    e_ty=fillmissing(e_ty,'linear');

    x=ncread([addxyt 'icemotion_daily_sh_25km_' num2str(jj, '%02d') '0101_'...
        num2str(jj, '%02d') '1231_v4.1.nc'],'x');
    y=ncread([addxyt 'icemotion_daily_sh_25km_' num2str(jj, '%02d') '0101_'...
        num2str(jj, '%02d') '1231_v4.1.nc'],'y');
    time=ncread([addxyt 'icemotion_daily_sh_25km_' num2str(jj, '%02d') '0101_'...
        num2str(jj, '%02d') '1231_v4.1.nc'],'time');
    crs=ncread([addxyt 'icemotion_daily_sh_25km_' num2str(jj, '%02d') '0101_'...
        num2str(jj, '%02d') '1231_v4.1.nc'],'crs');

    
    file=strcat([addlst{ii} 'tau.' num2str(jj, '%02d') '.nc']);
    lon=ncread(file,'lon');
    lat=ncread(file,'lat');
    TAUU=ncread(file,'TAUU');
    TAUV=ncread(file,'TAUV');
    e_TAU=ncread(file,'e_TAU');
    Alpha=ncread(file,'Alpha');Alpha=double(isnan(Alpha));
    TAUU(isnan(Alpha))=nan;TAUV(isnan(Alpha))=nan;e_TAU(isnan(Alpha))=nan;
    TAUU(TAUU==0)=nan;TAUV(TAUV==0)=nan;e_TAU(e_TAU==0)=nan;
    TAUU(isinf(TAUU))=nan;TAUV(isinf(TAUV))=nan;e_TAU(isinf(e_TAU))=nan;
    e_tx(isnan(TAUU))=nan;e_ty(isnan(TAUV))=nan;
    e_tx(isinf(e_tx))=nan;e_ty(isinf(e_ty))=nan;
    TAU=sqrt(TAUU.^2 + TAUV.^2);


    file=strcat('../test/Antarctic/Stress/WHOI_OAFlux_Antarctic_Surface_Stress_v1_',num2str(jj), '.nc');
if isfile(file), delete(file); end % Remove file if it exists

% Step 1: Define and write CRS (Coordinate Reference System) information
crs_var = 'crs';
nccreate(file, crs_var, 'DataType', 'int32');
tmp_att.grid_mapping_name = 'lambert_azimuthal_equal_area';
tmp_att.latitude_of_projection_origin = -90.0; % Change to -90.0 for Southern Hemisphere
tmp_att.longitude_of_projection_origin = 0.0;
tmp_att.false_easting = 0.0;
tmp_att.false_northing = 0.0;
tmp_att.semi_major_axis = 6378137.0; % WGS 84 spheroid
tmp_att.inverse_flattening = 298.257223563; % WGS 84 ellipsoid
tmp_att.long_name = 'EASEgrid_S25km';
tmp_att.srid = 'urn:ogc:def:crs:EPSG::3409';
tmp_att.proj4text = '+proj=laea +lat_0=-90 +lon_0=0 +x_0=0 +y_0=0 +a=6371228 +b=6371228 +units=m +no_defs';
tmp_att.datum = 'WGS84';
tmp_att.prime_meridian = 'Greenwich';

tmp_att.crs_wkt = ' PROJCS["NSIDC EASE-Grid South",GEOGCS["Unspecified datum based upon the International 1924 Authalic Sphere",DATUM["Not_specified_based_on_International_1924_Authalic_Sphere",SPHEROID["International 1924 Authalic Sphere",6371228,0,AUTHORITY["EPSG","7057"]],AUTHORITY["EPSG","6053"]],PRIMEM["Greenwich",0,AUTHORITY["EPSG","8901"]],UNIT["degree",0.01745329251994328,AUTHORITY["EPSG","9122"]],AUTHORITY["EPSG","4053"]],UNIT["metre",1,AUTHORITY["EPSG","9001"]],PROJECTION["Lambert_Azimuthal_Equal_Area"],PARAMETER["latitude_of_center",-90],PARAMETER["longitude_of_center",0],PARAMETER["false_easting",0],PARAMETER["false_northing",0],AUTHORITY["EPSG","3409"],AXIS["X",UNKNOWN],AXIS["Y",UNKNOWN]] ';
for fn = fieldnames(tmp_att)'
    ncwriteatt(file, crs_var, fn{1}, tmp_att.(fn{1}));
end

% Step 2: Add projection variables with compression and fillValue
tmp_att.long_name = 'projection_x_coordinate';
tmp_att.units = 'meters';
tmp_att.FillValue = -9999; % Adding fillValue for missing data
tmp_att.DeflateLevel = 4; % Apply compression
nccreate(file, 'x', 'Dimensions', {'x', length(x)}, 'Datatype', 'double');
ncwrite(file, 'x', x);
ncwriteatt(file, 'x', 'standard_name', tmp_att.long_name);
ncwriteatt(file, 'x', 'units', tmp_att.units);
ncwriteatt(file, 'x', 'coverage_content_type', 'coordinate');
ncwriteatt(file, 'x', 'long_name', 'x');
ncwriteatt(file, 'x', 'axis', 'X');
ncwriteatt(file, 'x', 'grid_mapping', crs_var);

tmp_att.long_name = 'projection_y_coordinate';
tmp_att.units = 'meters';
nccreate(file, 'y', 'Dimensions', {'y', length(y)}, 'Datatype', 'double');
ncwrite(file, 'y', y);
ncwriteatt(file, 'y', 'standard_name', tmp_att.long_name);
ncwriteatt(file, 'y', 'units', tmp_att.units);
ncwriteatt(file, 'y', 'coverage_content_type', 'coordinate');
ncwriteatt(file, 'y', 'long_name', 'y');
ncwriteatt(file, 'y', 'axis', 'Y');
ncwriteatt(file, 'y', 'grid_mapping', crs_var);

% Step 3: Define time as int-encoded datetime
tmp_att.long_name = 'time';
tmp_att.units = 'days since 1970-01-01';
tmp_att.FillValue = -9999;
time_encoded = int32(time); % Convert to integer days
nccreate(file, 'time', 'Dimensions', {'time', length(time)}, 'Datatype', 'int32');
ncwrite(file, 'time', time_encoded);
ncwriteatt(file, 'time', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'time', 'units', tmp_att.units);

% Step 4: Write geographic variables (longitude and latitude)
tmp_att.long_name = 'longitude';
tmp_att.units = 'degree_east';
nccreate(file, 'lon', 'Dimensions', {'x', 'y'}, 'DeflateLevel', tmp_att.DeflateLevel);
ncwrite(file, 'lon', lon);
ncwriteatt(file, 'lon', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'lon', 'units', tmp_att.units);
ncwriteatt(file, 'lon', 'grid_mapping', crs_var);

tmp_att.long_name = 'latitude';
tmp_att.units = 'degree_north';
nccreate(file, 'lat', 'Dimensions', {'x', 'y'}, 'DeflateLevel', tmp_att.DeflateLevel);
ncwrite(file, 'lat', lat);
ncwriteatt(file, 'lat', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'lat', 'units', tmp_att.units);
ncwriteatt(file, 'lat', 'grid_mapping', crs_var);

% Step 5: Land mask with compression and fillValue
tmp_att.long_name = 'Land Mask, 1 for land, 0 for ocean';
tmp_att.units = '';
nccreate(file, 'land_msk', 'Dimensions', {'x', 'y', 'time'}, 'Datatype', 'int8', 'DeflateLevel', tmp_att.DeflateLevel);
ncwrite(file, 'land_msk', int8(Alpha));
ncwriteatt(file, 'land_msk', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'land_msk', 'grid_mapping', crs_var);

% Step 6: Ocean stress variables (apply scaling and fillValue)
scale_factor = 1e-6; % Scaling for precision


% Ocean-Surface Stress
tmp_att.long_name = 'Ocean-Surface Stress';
tmp_att.units = 'N·m-2';
add_offset_TAU = mean(TAU, 'all','omitnan');
nccreate(file, 'TAU', 'Dimensions', {'x', 'y', 'time'}, 'Datatype', 'int32', 'DeflateLevel', tmp_att.DeflateLevel, 'FillValue', tmp_att.FillValue);
tmp=int32((TAU - add_offset_TAU) / scale_factor);tmp(tmp==0)=-9999;
ncwrite(file, 'TAU', tmp);
ncwriteatt(file, 'TAU', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'TAU', 'units', tmp_att.units);
ncwriteatt(file, 'TAU', 'scale_factor', scale_factor);
ncwriteatt(file, 'TAU', 'add_offset', add_offset_TAU);
ncwriteatt(file, 'TAU', 'grid_mapping', crs_var);

% Ocean-Surface Stress (zonal component)
tmp_att.long_name = 'Ocean-Surface Stress, zonal component';
tmp_att.units = 'N·m-2';
add_offset_TAUx = mean(TAUU(:), 'all','omitnan');
nccreate(file, 'TAUx', 'Dimensions', {'x', 'y', 'time'}, 'Datatype', 'int32', 'DeflateLevel', tmp_att.DeflateLevel, 'FillValue', tmp_att.FillValue);
tmp=int32((TAUU - add_offset_TAUx) / scale_factor);tmp(tmp==0)=-9999;
ncwrite(file, 'TAUx', tmp);
ncwriteatt(file, 'TAUx', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'TAUx', 'units', tmp_att.units);
ncwriteatt(file, 'TAUx', 'scale_factor', scale_factor);
ncwriteatt(file, 'TAUx', 'add_offset', add_offset_TAUx);
ncwriteatt(file, 'TAUx', 'grid_mapping', crs_var);

% Ocean-Surface Stress (meridional component)
tmp_att.long_name = 'Ocean-Surface Stress, meridional component';
tmp_att.units = 'N·m-2';
add_offset_TAUy = mean(TAUV(:), 'all','omitnan');
nccreate(file, 'TAUy', 'Dimensions', {'x', 'y', 'time'}, 'Datatype', 'int32', 'DeflateLevel', tmp_att.DeflateLevel, 'FillValue', tmp_att.FillValue);
tmp=int32((TAUV - add_offset_TAUy) / scale_factor);tmp(tmp==0)=-9999;
ncwrite(file, 'TAUy', tmp);
ncwriteatt(file, 'TAUy', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'TAUy', 'units', tmp_att.units);
ncwriteatt(file, 'TAUy', 'scale_factor', scale_factor);
ncwriteatt(file, 'TAUy', 'add_offset', add_offset_TAUy);
ncwriteatt(file, 'TAUy', 'grid_mapping', crs_var);

% Uncertainty estimates for TAUx
tmp_att.long_name = 'uncertainty estimate, TAUx';
tmp_att.units = 'N·m-2';
add_offset_e_TAUx = mean(e_tx(:), 'all','omitnan');
nccreate(file, 'e_TAUx', 'Dimensions', {'x', 'y', 'time'}, 'Datatype', 'int32', 'DeflateLevel', tmp_att.DeflateLevel, 'FillValue', tmp_att.FillValue);
tmp=int32((e_tx - add_offset_e_TAUx) / scale_factor);tmp(tmp==0)=-9999;
ncwrite(file, 'e_TAUx', tmp);
ncwriteatt(file, 'e_TAUx', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'e_TAUx', 'units', tmp_att.units);
ncwriteatt(file, 'e_TAUx', 'scale_factor', scale_factor);
ncwriteatt(file, 'e_TAUx', 'add_offset', add_offset_e_TAUx);
ncwriteatt(file, 'e_TAUx', 'grid_mapping', crs_var);

% Uncertainty estimates for TAUy
tmp_att.long_name = 'uncertainty estimate, TAUy';
tmp_att.units = 'N·m-2';
add_offset_e_TAUy = mean(e_ty(:), 'all','omitnan');
nccreate(file, 'e_TAUy', 'Dimensions', {'x', 'y', 'time'}, 'Datatype', 'int32', 'DeflateLevel', tmp_att.DeflateLevel, 'FillValue', tmp_att.FillValue);
tmp=int32((e_ty - add_offset_e_TAUy) / scale_factor);tmp(tmp==0)=-9999;
ncwrite(file, 'e_TAUy', tmp);
ncwriteatt(file, 'e_TAUy', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'e_TAUy', 'units', tmp_att.units);
ncwriteatt(file, 'e_TAUy', 'scale_factor', scale_factor);
ncwriteatt(file, 'e_TAUy', 'add_offset', add_offset_e_TAUy);
ncwriteatt(file, 'e_TAUy', 'grid_mapping', crs_var);

% Ocean stress variables
scale_factor = 1e-12; % Scaling for precision

% Ekman Pumping Rate
tmp_att.long_name = 'Ekman Pumping Rate, positive is upwelling, negative is downwelling';
tmp_att.units = 'm·s−1';
add_offset_We = mean(e_TAU(:), 'all','omitnan');
nccreate(file, 'We', 'Dimensions', {'x', 'y', 'time'}, 'Datatype', 'int32', 'DeflateLevel', tmp_att.DeflateLevel, 'FillValue', tmp_att.FillValue);
tmp=int32((e_TAU - add_offset_We) / scale_factor);tmp(tmp==0)=-9999;
ncwrite(file, 'We', tmp);
ncwriteatt(file, 'We', 'long_name', tmp_att.long_name);
ncwriteatt(file, 'We', 'units', tmp_att.units);
ncwriteatt(file, 'We', 'scale_factor', scale_factor);
ncwriteatt(file, 'We', 'add_offset', add_offset_We);
ncwriteatt(file, 'We', 'grid_mapping', crs_var);

% Step 9: Global attributes (title, conventions, source)
ncwriteatt(file, "/", "title", "Satellite-based Surface Stress in the Antarctic Ocean");
ncwriteatt(file, "/", "Conventions", "CF-1.8");
ncwriteatt(file, "/", "source", "Chao Liu, chao.liu@whoi.edu");
end
end

fprintf('end of all \n')
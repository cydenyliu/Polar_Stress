root_dir = '/mnt/data/oaflux/data8';
% root_dir = '/Users/chaoliu/oaflux/data8';
load('ref.mat')
% parameter
De = 20;
ro = 1027.5; ra = 1.25;
Cdi = 0.0055;
yy = 2011;
yo = 1;
dofy = 0;

lat_oa = -89.875:0.25:89.875;
lon_oa = .125:0.25:359.875;
[lat_oa, lon_oa] = meshgrid(lat_oa, lon_oa);
lon_oa(lon_oa>180) = lon_oa(lon_oa>180)-360;
lon_oa_p = lon_oa(721,:)+360;

msk_match=1; % activate when ==1, deactivate when ==0

angc_g_standard = cosd(lon_standard);
angs_g_standard = sind(lon_standard);

% ice extent
sub_dir_Ai = [root_dir '/ice_stress/main/input_data/NSIDC0051'];
file_dir_Ai = [sub_dir_Ai '/NSIDC0771_LatLon_PS_N25km_v1.0.nc'];
lat_Ai = ncread(file_dir_Ai, 'latitude');
lon_Ai = ncread(file_dir_Ai, 'longitude');

% ice motion
sub_dir_im = [root_dir '/ice_stress/main/input_data/icemotion_vectors_v4/north/daily'];
file_dir_im = [sub_dir_im '/icemotion_daily_nh_25km_' num2str(yy) '0101_' num2str(yy) '1231_v4.1.nc'];
if yo == 1
    lat_i = double(ncread(file_dir_im, 'latitude'));
    lon_i = double(ncread(file_dir_im, 'longitude'));

    % standard
    lon_i = double(lon_i);
    lat_i = double(lat_i);
    f = coriolisf(lat_standard);
end

% wind
sub_dir_wnd = [root_dir '/OAwnd_Daily'];

for mm = 1:12
    dinm = eomday(yy,mm);

    % wind
    file_dir_wnd = [sub_dir_wnd '/' num2str(yy)];
    uu_oa_m = load([file_dir_wnd '/taux.' num2str(yy) num2str(mm, '%02d') '.mat']);
    vv_oa_m = load([file_dir_wnd '/tauy.' num2str(yy) num2str(mm, '%02d') '.mat']);

    for dd = 1:dinm
        dofy = dofy+1;


        % ice extent
        sub_dir_Ai = [root_dir '/ice_stress/main/input_data/NSIDC0051'];
        file_dir_Ai = [sub_dir_Ai '/' num2str(yy) '/NSIDC0051_SEAICE_PS_N25km_'...
            num2str(yy) num2str(mm, '%02d') num2str(dd, '%02d') '_v2.0.nc'];
        Alphai = ncread(file_dir_Ai,'F17_ICECON');
        Alphai = double(Alphai);

        % ice motion
        xx_i = double(ncread(file_dir_im, 'u', [1 1 dofy], [inf inf 1]));
        yy_i = double(ncread(file_dir_im, 'v', [1 1 dofy], [inf inf 1]));
        % wind
        uu_oa = uu_oa_m.taux(:,:,dd);
        vv_oa = vv_oa_m.tauy(:,:,dd);

        % interpolation

        % refit EASE-grid
        % ice motion
        xx_i_standard = xx_i(49:end-48,49:end-48);
        yy_i_standard = yy_i(49:end-48,49:end-48);
        xx_i_standard(isnan(xx_i_standard)) = 0;
        yy_i_standard(isnan(yy_i_standard)) = 0;

        uu_i_standard = xx_i_standard.*angc_g_standard + yy_i_standard.*angs_g_standard;
        vv_i_standard =-xx_i_standard.*angs_g_standard + yy_i_standard.*angc_g_standard;

        % ice extent
        Alphai = Alphai*100;
        Alphai(Alphai>100) = nan;
        lon_Ai_db=[lon_Ai;lon_Ai(159,:)-360;lon_Ai(158,:)+360];
        lat_Ai_db=[lat_Ai;lat_Ai(159,:);lat_Ai(158,:)];
        Alphai=[Alphai;Alphai(159,:);Alphai(158,:)];

        Alpha_standardi = griddata(lon_Ai_db, lat_Ai_db, Alphai, lon_standard, lat_standard);
        Alpha_standardi = round(Alpha_standardi);
        Alpha_standardi(Alpha_standardi>100) = nan;
        Alpha_standard = Alpha_standardi;

        % wind stress to EASE-grid
        lon_oa_db = [lon_oa_p; lon_oa]; lat_oa_db = [lat_oa(721,:); lat_oa];
        uu_oa_db = [uu_oa(721,:); uu_oa]; vv_oa_db = [vv_oa(721,:); vv_oa];
        uu_oa_db(isnan(uu_oa_db)) = 0; vv_oa_db(isnan(vv_oa_db)) = 0;
        uu_oa_standard = griddata(lon_oa_db, lat_oa_db, uu_oa_db, lon_standard, lat_standard);
        vv_oa_standard = griddata(lon_oa_db, lat_oa_db, vv_oa_db, lon_standard, lat_standard);
        clear lon_oa_db lat_oa_db tauu_oa_db tauv_oa_db
% pause
        % mask fitting
        if msk_match==1
            mask_A = ~isnan(Alpha_standard);
            wmsk=uu_oa_standard==0;wmsk=logical(wmsk.*mask_A);
            % Alpha
            tmp=Alpha_standard;
            b00=tmp==0;
            tmp(logical(b00.*wmsk))=nan;
            tmp(~mask_A)=0;
            tmp=(fillmissing(tmp,'linear')+(fillmissing(tmp','linear'))')/2;
            tmp(~mask_A)=nan;
            Alpha_standard=tmp;

            % ice motion
            theta_i_standard = atan2(vv_i_standard, uu_i_standard);
            speed_i_standard = sqrt(uu_i_standard.^2 + vv_i_standard.^2);

            tmp=theta_i_standard;tmp(speed_i_standard==0)=0;
            tmp(~mask_A)=nan;
            b00=tmp==0;
            tmp(logical(b00.*wmsk))=nan;
            tmp2=tmp';
            tmp3=fillmissing(tmp(wmsk),'linear');tmp(wmsk)=tmp3;
            tmp3=fillmissing(tmp2(wmsk'),'linear');tmp2(wmsk')=tmp3;
            theta_i_standard=(tmp+tmp2')/2;

            tmp=speed_i_standard;
            tmp(~mask_A)=nan;
            b00=tmp==0;
            tmp(logical(b00.*wmsk))=nan;
            tmp2=tmp';
            tmp3=fillmissing(tmp(mask_A),'linear');tmp(mask_A)=tmp3;
            tmp3=fillmissing(tmp2(mask_A'),'linear');tmp2(mask_A')=tmp3;
            speed_i_standard=(tmp+tmp2')/2;

            speed_i_standard(~mask_A)=0;theta_i_standard(~mask_A)=0;

            uu_i_standard = speed_i_standard .* cos(theta_i_standard);
            vv_i_standard = speed_i_standard .* sin(theta_i_standard);
        end
        U_i = uu_i_standard+vv_i_standard*1i;
        U_ice(:,:,dofy)=U_i;
        U_w = uu_oa_standard+vv_oa_standard*1i;
        U_wnd(:,:,dofy)=U_w;
        SIC_Alpha(:,:,dofy)=Alpha_standard;
    end
end
save vel SIC_Alpha U_wnd U_ice
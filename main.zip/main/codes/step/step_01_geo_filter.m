
root_dir = '/mnt/data/oaflux/data8';
load('ref.mat')
% parameter
De = 20;
ro = 1027.5; ra = 1.25;
Cdi = 0.0055;

sgm=3;flt=6; % filter is activated when flt ~=1; 1 == 25 km, 6 == 150 km 

yy = 2011;
yo = 1;
dofy = 0;

% geo vel
sub_dir_gc_avi = [root_dir '/ice_stress/main/input_data/dt-phy-grids/altimetry_arctic'];
file_dir_gc = [sub_dir_gc_avi '/version_02_00/multimission/dt_arctic_multimission_sea_level_20110103.nc'];
if yo == 1
    lat_g = double(ncread(file_dir_gc, 'latitude'));
    lon_g = double(ncread(file_dir_gc, 'longitude'));
    lon_g_db = [lon_g(:,1:174) lon_g(:,176)-360 lon_g(:,174)+360 lon_g(:,176:end)];
    lat_g_db = [lat_g(:,1:174) lat_g(:,176) lat_g(:,174) lat_g(:,176:end)];
end

for mm = 1:12
    dinm = eomday(yy,mm);
    for dd = 1:dinm
        dofy = dofy+1;

        % geo vel
        file_dir_gc = [sub_dir_gc_avi '/daily_interp/' num2str(yy)];
        xy_g_m = load([file_dir_gc '/uv.' num2str(yy)  num2str(mm, '%02d')  num2str(dd, '%02d') '.mat']);
        xx_g = xy_g_m.uu;
        yy_g = xy_g_m.vv;


        % interpolation

        % geostrophic to EASE-grid
        xx_g = double(xx_g);
        yy_g = double(yy_g);

        xx_g_db = [xx_g(:,1:174) xx_g(:,176) xx_g(:,174) xx_g(:,176:end)];
        yy_g_db = [yy_g(:,1:174) yy_g(:,176) xx_g(:,174) yy_g(:,176:end)];
        xx_g_db(isnan(xx_g_db)) = 0; yy_g_db(isnan(yy_g_db)) = 0;
        xx_g_standard = griddata(lon_g_db, lat_g_db, xx_g_db, lon_standard, lat_standard);
        yy_g_standard = griddata(lon_g_db, lat_g_db, yy_g_db, lon_standard, lat_standard);
        clear xx_g_db yy_g_db

        % xy to uv
        uu_g_standard = xx_g_standard;
        vv_g_standard = yy_g_standard;
        % Complex
        if flt~=1
            uu_g_standard=Gau_conv_cl(uu_g_standard,flt,flt,sgm);
            vv_g_standard=Gau_conv_cl(vv_g_standard,flt,flt,sgm);
        end
        U_g = uu_g_standard+vv_g_standard*1i;
        U_geo(:,:,dofy)=U_g;
    end
end
save U_geo U_geo

function k = Gau_conv_cl(a, n, m, sigma)
% Custume Gaussian Convolution
% n x m matrix, sigma standard deviation
h = zeros(n,m);
for x=1:n
    for y=1:m
        h(x,y) = exp(-((x-n/2)^2+(y-m/2)^2)/(2*sigma^2));
    end
end
h = h/sum(h(:));
k = nanconv(a, h);
end